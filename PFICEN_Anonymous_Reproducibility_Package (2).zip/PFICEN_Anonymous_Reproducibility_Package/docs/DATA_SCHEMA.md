# Data Schema and File Selection

## Public sources

Development files are the October and November 2019 monthly files from the REES46 multi-category store dataset.

External files are the October 2019 through February 2020 monthly files from the REES46 cosmetics-shop dataset.

Use a separate raw directory for each source and place only the listed monthly files in that directory. The preparation manifest records every selected filename, byte size, and SHA-256 digest.

Public access points:

- `https://www.kaggle.com/datasets/mkechinov/ecommerce-behavior-data-from-multi-category-store`
- `https://www.kaggle.com/datasets/mkechinov/ecommerce-events-history-in-cosmetics-shop`
- `https://rees46.com/en/datasets`

## Required columns

| Column | Role |
|---|---|
| `event_time` | UTC event timestamp |
| `event_type` | `view`, `cart`, `remove_from_cart`, or `purchase` |
| `product_id` | Product identifier |
| `category_id` | Category identifier |
| `category_code` | Optional descriptive category field |
| `brand` | Brand identifier |
| `price` | Event price |
| `user_id` | User grouping and retrieval exclusion only |
| `user_session` | Supplied session boundary |

## Deterministic ordering and filtering

1. Retain rows with valid `user_id`, `user_session`, `event_time`, and supported `event_type`.
2. Parse timestamps as UTC.
3. Preserve original row number as a deterministic tie breaker.
4. Sort by `user_session`, `event_time`, and original row number.
5. Remove later occurrences sharing `user_id`, `user_session`, `event_time`, `event_type`, and `product_id`.
6. Do not construct an inactivity-based session boundary.
7. For sessions with purchases, the first purchase defines the outcome; that event and all later rows are unavailable to the predictor.

## Prepared files

`scripts/prepare_data.py` writes:

- `clean_events.parquet`: deterministically ordered and deduplicated source events;
- `session_index.parquet`: user, session, label, and time metadata used to create outer folds;
- `prefix_events.parquet`: one row per retained prefix event;
- `sessions.parquet`: one row per analytical session or landmark;
- `construction_counts.json`: stage-level event, session, and positive counts;
- `schema.json`: physical columns and dtypes;
- `preparation_manifest.json`: configuration digest and input file hashes.

