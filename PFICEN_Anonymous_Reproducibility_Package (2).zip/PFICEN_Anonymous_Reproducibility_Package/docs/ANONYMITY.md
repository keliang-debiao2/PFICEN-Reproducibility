# Anonymous Review Checklist

- Author names are replaced by `Anonymous Authors`.
- Affiliations and contact addresses are omitted.
- Source files contain no user-home or workstation-specific paths.
- Data locations are provided only through command-line arguments and configuration keys.
- Repository hosting accounts and commit history are not included in the archive.
- Runtime records use relative paths and neutral run identifiers.
- Public dataset citations do not identify the manuscript authors.

Before public release after acceptance, replace the anonymous citation metadata and add the permanent repository identifier.

