# Result Provenance

The records under `logs/reference_runs/` and the tables under `results/reference/` are manuscript-aligned reference traces constructed from the confirmed values reported in the associated paper. They are not original console output captured from the training system.

Their purposes are to:

1. define the expected schema of execution-generated records;
2. preserve the fold, metric, ablation, calibration, robustness, and efficiency targets used to validate a reconstruction;
3. support automated comparison between a new run and the manuscript values; and
4. document the fixed methodological choices required for a faithful rerun.

These records must not be presented as evidence of an independently completed rerun. After executing the pipeline, keep the reference directory unchanged and store newly generated records in a separate run directory. Any public reproducibility claim should rely on those newly generated records and their captured environment metadata.

