# Prediction and Validation Protocol

## Outcome-aligned protocol

For a positive session, the prefix ends immediately before the first purchase and the prediction time is the last retained non-purchase event. For a negative session, a stable session hash selects a pseudo-landmark from the positive-prefix-length distribution estimated only on the current outer-training fold. Both classes use at most the 64 latest non-purchase events from the preceding 24 hours.

## Fifth-event protocol

The prediction time is the fifth non-purchase event. The prefix contains exactly five non-purchase events. The target is one when the first purchase occurs after that event and no later than 30 minutes afterward. Sessions with fewer than five non-purchase events are excluded.

## Validation

- Five outer folds use `user_id` as the grouping variable and seed 2026.
- Ten percent of outer-training users form a disjoint inner-validation set.
- Inner validation controls hyperparameters, early stopping, temperature, and F1 threshold.
- Stochastic fitting seeds are 42, 2027, 3407, 27182, and 31415.
- Chronological confirmation assigns samples using the fifth-event timestamp: October 2019 for training, 1–7 November for inner validation, and 8–30 November for testing.
- External inference averages calibrated probabilities from the five frozen outer-fold models.

## Statistical inference

Internal paired differences use 10,000 user-clustered bootstrap replicates of pooled out-of-fold predictions. External differences use 10,000 paired session-level replicates. Report two-sided percentile intervals and two-sided tail-probability p-values. Apply Holm correction to the prespecified comparison family.

