# Manuscript-to-Code Mapping

| Manuscript component | Implementation |
|---|---|
| Data construction and prefix protocols | `src/pficen/protocols.py` |
| User-grouped and chronological partitions | `src/pficen/splits.py` |
| Fold-specific vocabularies and numerical transforms | `src/pficen/preprocessing.py` |
| Event tensor dataset and collation | `src/pficen/dataset.py` |
| Continuous-time funnel encoder | `src/pficen/model.py` |
| Label-stratified FAISS retrieval and exclusion rules | `src/pficen/retrieval.py` |
| Main and auxiliary losses | `src/pficen/losses.py` |
| Training, index refresh, and prediction | `src/pficen/engine.py` |
| Temperature scaling and threshold selection | `src/pficen/calibration.py` |
| Metrics and reliability bins | `src/pficen/metrics.py` |
| Paired bootstrap and Holm correction | `src/pficen/statistics.py` |
| Aggregate and sequence baselines | `src/pficen/baselines.py` |
| MLP, FT-Transformer, GRU, and LSTM baselines | `src/pficen/neural_baselines.py` |
| TabPFN-3 and TabFM context construction | `src/pficen/foundation_adapters.py` |
| End-to-end commands | `scripts/` |

