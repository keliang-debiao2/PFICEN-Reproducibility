from __future__ import annotations

from pathlib import Path

import pandas as pd

from .protocols import REQUIRED_COLUMNS


def discover_data_files(directory: str | Path) -> list[Path]:
    directory = Path(directory)
    files = []
    for pattern in ("*.csv", "*.csv.gz", "*.parquet"):
        files.extend(directory.glob(pattern))
    files = sorted(set(files))
    if not files:
        raise FileNotFoundError(f"no supported data files found in {directory}")
    return files


def read_event_files(files: list[Path]) -> pd.DataFrame:
    frames = []
    for path in files:
        if path.suffix == ".parquet":
            frame = pd.read_parquet(path, columns=list(REQUIRED_COLUMNS))
        else:
            frame = pd.read_csv(path, usecols=lambda column: column in REQUIRED_COLUMNS, low_memory=False)
        frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def load_prepared(directory: str | Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    directory = Path(directory)
    sessions = pd.read_parquet(directory / "sessions.parquet")
    events = pd.read_parquet(directory / "prefix_events.parquet")
    return sessions, events

