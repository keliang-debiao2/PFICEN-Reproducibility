from __future__ import annotations

import numpy as np
from scipy.stats import t
from sklearn.metrics import average_precision_score, brier_score_loss


def descriptive_fold_interval(values: np.ndarray, confidence: float = 0.95) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    critical = t.ppf((1 + confidence) / 2, df=len(values) - 1)
    half = critical * values.std(ddof=1) / np.sqrt(len(values))
    return float(values.mean() - half), float(values.mean() + half)


def _metric(name: str, labels: np.ndarray, probabilities: np.ndarray) -> float:
    if name == "pr_auc":
        return float(average_precision_score(labels, probabilities))
    if name == "brier":
        return float(brier_score_loss(labels, probabilities))
    raise ValueError(f"unsupported bootstrap metric: {name}")


def paired_bootstrap(
    labels: np.ndarray,
    first: np.ndarray,
    second: np.ndarray,
    clusters: np.ndarray | None,
    metric: str = "pr_auc",
    replicates: int = 10000,
    seed: int = 2026,
) -> dict[str, float]:
    labels = np.asarray(labels)
    first = np.asarray(first)
    second = np.asarray(second)
    clusters = np.arange(len(labels)) if clusters is None else np.asarray(clusters)
    unique = np.unique(clusters)
    membership = {cluster: np.flatnonzero(clusters == cluster) for cluster in unique}
    rng = np.random.default_rng(seed)
    differences = np.empty(replicates, dtype=np.float64)
    for index in range(replicates):
        sampled = rng.choice(unique, size=len(unique), replace=True)
        rows = np.concatenate([membership[cluster] for cluster in sampled])
        differences[index] = _metric(metric, labels[rows], first[rows]) - _metric(metric, labels[rows], second[rows])
    estimate = _metric(metric, labels, first) - _metric(metric, labels, second)
    lower, upper = np.quantile(differences, [0.025, 0.975])
    p_value = min(1.0, 2.0 * min(float(np.mean(differences <= 0)), float(np.mean(differences >= 0))))
    return {"difference": estimate, "ci_lower": float(lower), "ci_upper": float(upper), "p_value": p_value}


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    count = len(values)
    for rank, original_index in enumerate(order):
        candidate = (count - rank) * values[original_index]
        running = max(running, candidate)
        adjusted[original_index] = min(1.0, running)
    return adjusted.tolist()

