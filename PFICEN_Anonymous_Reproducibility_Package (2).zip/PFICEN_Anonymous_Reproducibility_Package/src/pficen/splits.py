from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold


def outer_user_folds(sessions: pd.DataFrame, n_splits: int = 5, seed: int = 2026) -> np.ndarray:
    required = {"user_id", "label"}
    if not required.issubset(sessions.columns):
        raise ValueError(f"sessions must contain {sorted(required)}")
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    folds = np.full(len(sessions), -1, dtype=np.int16)
    dummy = np.zeros(len(sessions), dtype=np.int8)
    for fold, (_, test_index) in enumerate(splitter.split(dummy, sessions["label"], groups=sessions["user_id"])):
        folds[test_index] = fold
    if np.any(folds < 0):
        raise RuntimeError("incomplete fold assignment")
    return folds


def inner_user_split(
    outer_train: pd.DataFrame,
    validation_fraction: float = 0.10,
    seed: int = 2026,
) -> tuple[np.ndarray, np.ndarray]:
    users = outer_train.groupby("user_id", sort=False)["label"].max().reset_index()
    rng = np.random.default_rng(seed)
    validation_users: set[str] = set()
    for label, block in users.groupby("label"):
        values = block["user_id"].astype(str).to_numpy()
        rng.shuffle(values)
        count = max(1, int(round(len(values) * validation_fraction)))
        validation_users.update(values[:count].tolist())
    is_validation = outer_train["user_id"].astype(str).isin(validation_users).to_numpy()
    return np.flatnonzero(~is_validation), np.flatnonzero(is_validation)


def chronological_fifth_event_split(sessions: pd.DataFrame) -> np.ndarray:
    time = pd.to_datetime(sessions["prediction_time"], utc=True)
    split = np.full(len(sessions), "excluded", dtype=object)
    split[(time >= "2019-10-01") & (time < "2019-11-01")] = "train"
    split[(time >= "2019-11-01") & (time < "2019-11-08")] = "validation"
    split[(time >= "2019-11-08") & (time < "2019-12-01")] = "test"
    return split


def assert_user_disjoint(sessions: pd.DataFrame, split_column: str) -> None:
    counts = sessions.groupby("user_id")[split_column].nunique()
    if int(counts.max()) > 1:
        raise AssertionError("a user appears in more than one requested partition")

