from __future__ import annotations

import numpy as np
import pandas as pd


def feature_missingness(events: pd.DataFrame, probability: float, seed: int) -> pd.DataFrame:
    output = events.copy()
    rng = np.random.default_rng(seed)
    for field in ("product_id", "category_id", "brand", "price"):
        mask = rng.random(len(output)) < probability
        output.loc[mask, field] = np.nan
    return output


def price_noise(events: pd.DataFrame, sigma: float, seed: int) -> pd.DataFrame:
    output = events.copy()
    observed = output["price"].notna()
    rng = np.random.default_rng(seed)
    noise = rng.normal(0.0, sigma, int(observed.sum()))
    output.loc[observed, "price"] = pd.to_numeric(output.loc[observed, "price"]) * np.exp(noise)
    return output


def fixed_prefix(events: pd.DataFrame, retained_events: int) -> pd.DataFrame:
    return events.sort_values(["session_id", "position"], kind="stable").groupby("session_id", sort=False).head(retained_events).copy()


def select_user_fraction(sessions: pd.DataFrame, fraction: float, seed: int) -> pd.DataFrame:
    users = sessions["user_id"].astype(str).unique()
    rng = np.random.default_rng(seed)
    selected = rng.choice(users, size=max(1, int(round(len(users) * fraction))), replace=False)
    return sessions.loc[sessions["user_id"].astype(str).isin(selected)].copy()

