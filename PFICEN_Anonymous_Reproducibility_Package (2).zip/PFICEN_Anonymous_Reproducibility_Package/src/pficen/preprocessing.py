from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

EVENT_TO_ID = {"view": 0, "cart": 1, "remove_from_cart": 2}
PAD_ID = 0
MISSING_ID = 1
UNKNOWN_ID = 2


@dataclass
class FieldVocabulary:
    mapping: dict[str, int] = field(default_factory=dict)

    def fit(self, values: pd.Series) -> "FieldVocabulary":
        tokens = sorted({str(v) for v in values.dropna().unique()})
        self.mapping = {token: index + 3 for index, token in enumerate(tokens)}
        return self

    def transform(self, values: pd.Series) -> np.ndarray:
        output = np.full(len(values), UNKNOWN_ID, dtype=np.int64)
        missing = values.isna().to_numpy()
        output[missing] = MISSING_ID
        for index, value in enumerate(values):
            if missing[index]:
                continue
            output[index] = self.mapping.get(str(value), UNKNOWN_ID)
        return output

    @property
    def size(self) -> int:
        return len(self.mapping) + 3


@dataclass
class FoldPreprocessor:
    price_quantiles: tuple[float, float] = (0.001, 0.999)
    product_vocab: FieldVocabulary = field(default_factory=FieldVocabulary)
    category_vocab: FieldVocabulary = field(default_factory=FieldVocabulary)
    brand_vocab: FieldVocabulary = field(default_factory=FieldVocabulary)
    price_lower: float = 0.0
    price_upper: float = 0.0
    price_median: float = 0.0
    price_log_mean: float = 0.0
    price_log_std: float = 1.0

    def fit(self, events: pd.DataFrame) -> "FoldPreprocessor":
        self.product_vocab.fit(events["product_id"])
        self.category_vocab.fit(events["category_id"])
        self.brand_vocab.fit(events["brand"])
        price = pd.to_numeric(events["price"], errors="coerce")
        observed = price.dropna().clip(lower=0)
        if observed.empty:
            raise ValueError("outer-training events contain no observed prices")
        self.price_lower, self.price_upper = np.quantile(observed, self.price_quantiles).tolist()
        self.price_median = float(observed.median())
        transformed = np.log1p(observed.clip(self.price_lower, self.price_upper))
        self.price_log_mean = float(transformed.mean())
        self.price_log_std = max(float(transformed.std(ddof=0)), 1e-8)
        return self

    def transform(self, events: pd.DataFrame) -> pd.DataFrame:
        output = events.copy()
        output["event_id"] = output["event_type"].map(EVENT_TO_ID).fillna(3).astype(np.int64)
        output["product_token"] = self.product_vocab.transform(output["product_id"])
        output["category_token"] = self.category_vocab.transform(output["category_id"])
        output["brand_token"] = self.brand_vocab.transform(output["brand"])
        price = pd.to_numeric(output["price"], errors="coerce")
        output["price_missing"] = price.isna().astype(np.float32)
        price = price.fillna(self.price_median).clip(self.price_lower, self.price_upper)
        output["price_scaled"] = ((np.log1p(price) - self.price_log_mean) / self.price_log_std).astype(np.float32)
        output["event_time"] = pd.to_datetime(output["event_time"], utc=True)
        output["time_seconds"] = output["event_time"].astype("int64") / 1e9
        output["gap_seconds"] = (
            output.groupby("session_id", sort=False)["time_seconds"].diff().fillna(0).clip(0, 24 * 3600)
        )
        output["gap_log"] = np.log1p(output["gap_seconds"]).astype(np.float32)
        return output

    def vocabulary_sizes(self) -> dict[str, int]:
        return {
            "product": self.product_vocab.size,
            "category": self.category_vocab.size,
            "brand": self.brand_vocab.size,
        }

