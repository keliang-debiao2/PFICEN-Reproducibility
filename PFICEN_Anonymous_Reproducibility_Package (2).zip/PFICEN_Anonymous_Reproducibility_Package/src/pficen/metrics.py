from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    average_precision_score,
    balanced_accuracy_score,
    brier_score_loss,
    f1_score,
    log_loss,
    roc_auc_score,
)


def equal_frequency_ece(labels: np.ndarray, probabilities: np.ndarray, bins: int = 15) -> float:
    labels = np.asarray(labels)
    probabilities = np.asarray(probabilities)
    order = np.argsort(probabilities, kind="stable")
    chunks = np.array_split(order, bins)
    total = len(labels)
    return float(sum(len(chunk) / total * abs(labels[chunk].mean() - probabilities[chunk].mean()) for chunk in chunks if len(chunk)))


def reliability_bins(labels: np.ndarray, probabilities: np.ndarray, bins: int = 15) -> list[dict[str, float]]:
    order = np.argsort(probabilities, kind="stable")
    records = []
    for index, chunk in enumerate(np.array_split(order, bins)):
        if len(chunk):
            records.append({"bin": index + 1, "count": len(chunk), "mean_probability": float(probabilities[chunk].mean()), "observed_rate": float(labels[chunk].mean())})
    return records


def classification_metrics(labels: np.ndarray, probabilities: np.ndarray, threshold: float, ece_bins: int = 15) -> dict[str, float]:
    labels = np.asarray(labels, dtype=np.int8)
    probabilities = np.asarray(probabilities, dtype=np.float64)
    predictions = probabilities >= threshold
    return {
        "pr_auc": float(average_precision_score(labels, probabilities)),
        "roc_auc": float(roc_auc_score(labels, probabilities)),
        "f1": float(f1_score(labels, predictions, zero_division=0)),
        "balanced_accuracy": float(balanced_accuracy_score(labels, predictions)),
        "brier": float(brier_score_loss(labels, probabilities)),
        "log_loss": float(log_loss(labels, np.column_stack((1 - probabilities, probabilities)), labels=[0, 1])),
        "ece": equal_frequency_ece(labels, probabilities, ece_bins),
    }

