from __future__ import annotations

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


class MLPBaseline(nn.Module):
    def __init__(self, input_dim: int, hidden_dims: tuple[int, int] = (512, 256), dropout: float = 0.20):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dims[0]), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(hidden_dims[0], hidden_dims[1]), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(hidden_dims[1], 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x).squeeze(-1)


class FTTransformerBaseline(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 128, layers: int = 3, heads: int = 8, feedforward_dim: int = 512, dropout: float = 0.10):
        super().__init__()
        self.weight = nn.Parameter(torch.randn(input_dim, hidden_dim) * 0.02)
        self.bias = nn.Parameter(torch.zeros(input_dim, hidden_dim))
        self.cls = nn.Parameter(torch.zeros(1, 1, hidden_dim))
        layer = nn.TransformerEncoderLayer(hidden_dim, heads, feedforward_dim, dropout, activation="gelu", batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, layers)
        self.head = nn.Linear(hidden_dim, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        tokens = x.unsqueeze(-1) * self.weight.unsqueeze(0) + self.bias.unsqueeze(0)
        cls = self.cls.expand(x.shape[0], -1, -1)
        encoded = self.encoder(torch.cat((cls, tokens), dim=1))
        return self.head(encoded[:, 0]).squeeze(-1)


class RecurrentSequenceBaseline(nn.Module):
    def __init__(self, vocabulary_sizes: dict[str, int], cell: str = "gru", hidden_dim: int = 128, layers: int = 2, dropout: float = 0.10):
        super().__init__()
        self.event = nn.Embedding(4, hidden_dim)
        self.product = nn.Embedding(vocabulary_sizes["product"], hidden_dim, padding_idx=0)
        self.category = nn.Embedding(vocabulary_sizes["category"], hidden_dim, padding_idx=0)
        self.brand = nn.Embedding(vocabulary_sizes["brand"], hidden_dim, padding_idx=0)
        self.numeric = nn.Linear(2, hidden_dim)
        recurrent = nn.GRU if cell.lower() == "gru" else nn.LSTM
        self.sequence = recurrent(hidden_dim, hidden_dim, num_layers=layers, dropout=dropout, batch_first=True, bidirectional=False)
        self.head = nn.Linear(hidden_dim, 1)

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        token = self.event(batch["event_id"]) + self.product(batch["product"]) + self.category(batch["category"]) + self.brand(batch["brand"]) + self.numeric(torch.stack((batch["price"], batch["price_missing"]), dim=-1))
        lengths = batch["mask"].sum(dim=1).cpu()
        packed = nn.utils.rnn.pack_padded_sequence(token, lengths, batch_first=True, enforce_sorted=False)
        _, hidden = self.sequence(packed)
        if isinstance(hidden, tuple):
            hidden = hidden[0]
        return self.head(hidden[-1]).squeeze(-1)


def fit_tabular_neural(
    model: nn.Module,
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_validation: np.ndarray,
    y_validation: np.ndarray,
    learning_rate: float = 3e-4,
    batch_size: int = 512,
    epochs: int = 50,
    patience: int = 5,
    device: str = "cuda" if torch.cuda.is_available() else "cpu",
) -> nn.Module:
    model = model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    train = DataLoader(TensorDataset(torch.as_tensor(x_train, dtype=torch.float32), torch.as_tensor(y_train, dtype=torch.float32)), batch_size=batch_size, shuffle=True)
    validation_x = torch.as_tensor(x_validation, dtype=torch.float32, device=device)
    validation_y = torch.as_tensor(y_validation, dtype=torch.float32, device=device)
    positive = max(float(np.sum(y_train)), 1.0)
    negative = max(float(len(y_train) - np.sum(y_train)), 1.0)
    positive_weight = torch.tensor(negative / positive, device=device)
    best = float("inf")
    best_state = None
    stale = 0
    for _ in range(epochs):
        model.train()
        for x, y in train:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = nn.functional.binary_cross_entropy_with_logits(model(x), y, pos_weight=positive_weight)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        model.eval()
        with torch.no_grad():
            loss = float(nn.functional.binary_cross_entropy_with_logits(model(validation_x), validation_y))
        if loss < best:
            best = loss
            best_state = {key: value.detach().cpu().clone() for key, value in model.state_dict().items()}
            stale = 0
        else:
            stale += 1
            if stale >= patience:
                break
    if best_state is None:
        raise RuntimeError("neural baseline training produced no checkpoint")
    model.load_state_dict(best_state)
    return model

