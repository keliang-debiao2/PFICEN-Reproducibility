from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd

from .utils import stable_hash

SUPPORTED_EVENTS = ("view", "cart", "remove_from_cart", "purchase")
NON_PURCHASE_EVENTS = ("view", "cart", "remove_from_cart")
REQUIRED_COLUMNS = (
    "event_time",
    "event_type",
    "product_id",
    "category_id",
    "brand",
    "price",
    "user_id",
    "user_session",
)


@dataclass(frozen=True)
class PrefixRecord:
    session_id: str
    user_id: str
    label: int
    prediction_time: pd.Timestamp
    events: pd.DataFrame
    duration_seconds: float
    exact_signature: str
    near_signature: str


def clean_events(frame: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, int]]:
    missing = set(REQUIRED_COLUMNS) - set(frame.columns)
    if missing:
        raise ValueError(f"missing required columns: {sorted(missing)}")
    data = frame.copy()
    data["_source_row"] = np.arange(len(data), dtype=np.int64)
    counts = {"raw_events": int(len(data)), "raw_sessions": int(data["user_session"].nunique(dropna=True))}
    data["event_time"] = pd.to_datetime(data["event_time"], utc=True, errors="coerce")
    data = data.sort_values(["user_session", "event_time", "_source_row"], kind="stable", na_position="last")
    duplicate_keys = ["user_id", "user_session", "event_time", "event_type", "product_id"]
    data = data.drop_duplicates(duplicate_keys, keep="first")
    counts["after_exact_duplicate_events"] = int(len(data))
    counts["after_exact_duplicate_sessions"] = int(data["user_session"].nunique(dropna=True))
    valid = (
        data["user_id"].notna()
        & data["user_session"].notna()
        & data["event_time"].notna()
        & data["event_type"].isin(SUPPORTED_EVENTS)
    )
    data = data.loc[valid].copy()
    counts["valid_events"] = int(len(data))
    counts["valid_sessions"] = int(data["user_session"].nunique())
    return data.reset_index(drop=True), counts


def _signature(events: pd.DataFrame, fields: Iterable[str]) -> str:
    values = events[list(fields)].fillna("<NA>").astype(str).agg("|".join, axis=1).tolist()
    return ">".join(values)


def _truncate_lookback(events: pd.DataFrame, max_events: int, lookback_hours: float) -> pd.DataFrame:
    if events.empty:
        return events
    end = events["event_time"].iloc[-1]
    start = end - pd.Timedelta(hours=lookback_hours)
    return events.loc[events["event_time"] >= start].tail(max_events).copy()


def positive_prefix_lengths(clean: pd.DataFrame) -> np.ndarray:
    lengths: list[int] = []
    for _, group in clean.groupby("user_session", sort=False):
        purchase_pos = np.flatnonzero(group["event_type"].to_numpy() == "purchase")
        if purchase_pos.size:
            before = group.iloc[: int(purchase_pos[0])]
            length = int(before["event_type"].isin(NON_PURCHASE_EVENTS).sum())
            if length > 0:
                lengths.append(length)
    if not lengths:
        raise ValueError("no eligible positive sessions found in the fitting partition")
    return np.asarray(lengths, dtype=np.int64)


def construct_outcome_aligned(
    clean: pd.DataFrame,
    training_positive_lengths: np.ndarray,
    max_events: int = 64,
    lookback_hours: float = 24.0,
    hash_seed: int = 2026,
) -> list[PrefixRecord]:
    records: list[PrefixRecord] = []
    sorted_lengths = np.sort(np.asarray(training_positive_lengths, dtype=np.int64))
    for session_id, group in clean.groupby("user_session", sort=False):
        group = group.sort_values(["event_time", "_source_row"], kind="stable")
        user_id = str(group["user_id"].iloc[0])
        purchase_pos = np.flatnonzero(group["event_type"].to_numpy() == "purchase")
        label = int(purchase_pos.size > 0)
        available = group.iloc[: int(purchase_pos[0])] if label else group
        available = available.loc[available["event_type"].isin(NON_PURCHASE_EVENTS)]
        if available.empty:
            continue
        if not label:
            quantile = (stable_hash(session_id, hash_seed) % 1_000_000) / 1_000_000.0
            index = min(int(quantile * len(sorted_lengths)), len(sorted_lengths) - 1)
            landmark_length = int(np.clip(sorted_lengths[index], 1, len(available)))
            available = available.iloc[:landmark_length]
        prefix = _truncate_lookback(available, max_events, lookback_hours)
        if prefix.empty:
            continue
        duration = float((prefix["event_time"].iloc[-1] - prefix["event_time"].iloc[0]).total_seconds())
        records.append(
            PrefixRecord(
                session_id=str(session_id),
                user_id=user_id,
                label=label,
                prediction_time=prefix["event_time"].iloc[-1],
                events=prefix,
                duration_seconds=max(duration, 0.0),
                exact_signature=_signature(prefix, ("event_type", "product_id", "category_id")),
                near_signature=_signature(prefix, ("event_type", "category_id")),
            )
        )
    return records


def construct_fifth_event(
    clean: pd.DataFrame,
    landmark_events: int = 5,
    horizon_minutes: float = 30.0,
) -> list[PrefixRecord]:
    records: list[PrefixRecord] = []
    horizon = pd.Timedelta(minutes=horizon_minutes)
    for session_id, group in clean.groupby("user_session", sort=False):
        group = group.sort_values(["event_time", "_source_row"], kind="stable")
        purchase_pos = np.flatnonzero(group["event_type"].to_numpy() == "purchase")
        first_purchase_time = group["event_time"].iloc[int(purchase_pos[0])] if purchase_pos.size else None
        candidate = group.iloc[: int(purchase_pos[0])] if purchase_pos.size else group
        non_purchase = candidate.loc[candidate["event_type"].isin(NON_PURCHASE_EVENTS)]
        if len(non_purchase) < landmark_events:
            continue
        prefix = non_purchase.iloc[:landmark_events].copy()
        prediction_time = prefix["event_time"].iloc[-1]
        label = int(first_purchase_time is not None and first_purchase_time > prediction_time and first_purchase_time <= prediction_time + horizon)
        duration = float((prediction_time - prefix["event_time"].iloc[0]).total_seconds())
        records.append(
            PrefixRecord(
                session_id=str(session_id),
                user_id=str(group["user_id"].iloc[0]),
                label=label,
                prediction_time=prediction_time,
                events=prefix,
                duration_seconds=max(duration, 0.0),
                exact_signature=_signature(prefix, ("event_type", "product_id", "category_id")),
                near_signature=_signature(prefix, ("event_type", "category_id")),
            )
        )
    return records


def records_to_frames(records: list[PrefixRecord]) -> tuple[pd.DataFrame, pd.DataFrame]:
    session_rows = []
    event_frames = []
    for record in records:
        session_rows.append(
            {
                "session_id": record.session_id,
                "user_id": record.user_id,
                "label": record.label,
                "prediction_time": record.prediction_time,
                "duration_seconds": record.duration_seconds,
                "exact_signature": record.exact_signature,
                "near_signature": record.near_signature,
                "prefix_length": len(record.events),
            }
        )
        events = record.events.copy()
        events["session_id"] = record.session_id
        events["position"] = np.arange(len(events), dtype=np.int16)
        event_frames.append(events)
    sessions = pd.DataFrame(session_rows)
    events = pd.concat(event_frames, ignore_index=True) if event_frames else pd.DataFrame()
    return sessions, events

