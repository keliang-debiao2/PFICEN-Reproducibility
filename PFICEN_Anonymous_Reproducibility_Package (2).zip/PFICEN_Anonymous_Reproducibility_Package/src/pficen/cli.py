from __future__ import annotations

import runpy
from pathlib import Path


def _run(script: str) -> None:
    path = Path(__file__).resolve().parents[2] / "scripts" / script
    runpy.run_path(str(path), run_name="__main__")


def prepare_main() -> None:
    _run("prepare_data.py")


def train_main() -> None:
    _run("run_cross_validation.py")


def evaluate_main() -> None:
    _run("run_external.py")

