from __future__ import annotations

import numpy as np
import torch
from sklearn.metrics import f1_score


class TemperatureScaler:
    def __init__(self):
        self.temperature = 1.0

    def fit(self, logits: np.ndarray, labels: np.ndarray) -> "TemperatureScaler":
        logits_tensor = torch.as_tensor(logits, dtype=torch.float64)
        labels_tensor = torch.as_tensor(labels, dtype=torch.float64)
        log_temperature = torch.zeros((), dtype=torch.float64, requires_grad=True)
        optimizer = torch.optim.LBFGS([log_temperature], lr=0.1, max_iter=100, line_search_fn="strong_wolfe")

        def closure():
            optimizer.zero_grad()
            temperature = torch.exp(log_temperature).clamp(0.05, 20.0)
            loss = torch.nn.functional.binary_cross_entropy_with_logits(logits_tensor / temperature, labels_tensor)
            loss.backward()
            return loss

        optimizer.step(closure)
        self.temperature = float(torch.exp(log_temperature).clamp(0.05, 20.0).detach())
        return self

    def transform_logits(self, logits: np.ndarray) -> np.ndarray:
        return np.asarray(logits, dtype=np.float64) / self.temperature

    def predict_proba(self, logits: np.ndarray) -> np.ndarray:
        scaled = self.transform_logits(logits)
        return 1.0 / (1.0 + np.exp(-scaled))


def select_f1_threshold(labels: np.ndarray, probabilities: np.ndarray) -> float:
    candidates = np.unique(np.quantile(probabilities, np.linspace(0, 1, 1001)))
    scores = np.asarray([f1_score(labels, probabilities >= threshold, zero_division=0) for threshold in candidates])
    return float(candidates[int(np.argmax(scores))])

