from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


@dataclass
class SessionItem:
    session_id: str
    user_id: str
    label: int
    duration_seconds: float
    exact_signature: str
    near_signature: str
    event_id: np.ndarray
    product: np.ndarray
    category: np.ndarray
    brand: np.ndarray
    price: np.ndarray
    price_missing: np.ndarray
    time_seconds: np.ndarray


class EventPrefixDataset(Dataset):
    def __init__(self, sessions: pd.DataFrame, events: pd.DataFrame, max_events: int = 64):
        self.items: list[SessionItem] = []
        metadata = sessions.set_index("session_id")
        for session_id, group in events.groupby("session_id", sort=False):
            if session_id not in metadata.index:
                continue
            row = metadata.loc[session_id]
            group = group.sort_values("position", kind="stable").tail(max_events)
            self.items.append(
                SessionItem(
                    session_id=str(session_id),
                    user_id=str(row["user_id"]),
                    label=int(row["label"]),
                    duration_seconds=float(row["duration_seconds"]),
                    exact_signature=str(row["exact_signature"]),
                    near_signature=str(row["near_signature"]),
                    event_id=group["event_id"].to_numpy(np.int64),
                    product=group["product_token"].to_numpy(np.int64),
                    category=group["category_token"].to_numpy(np.int64),
                    brand=group["brand_token"].to_numpy(np.int64),
                    price=group["price_scaled"].to_numpy(np.float32),
                    price_missing=group["price_missing"].to_numpy(np.float32),
                    time_seconds=group["time_seconds"].to_numpy(np.float64),
                )
            )

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, index: int) -> SessionItem:
        return self.items[index]


def collate_sessions(items: list[SessionItem]) -> dict[str, torch.Tensor | list[str]]:
    batch_size = len(items)
    length = max(len(item.event_id) for item in items)
    mask = torch.zeros(batch_size, length, dtype=torch.bool)
    integer_fields = {name: torch.zeros(batch_size, length, dtype=torch.long) for name in ("event_id", "product", "category", "brand")}
    float_fields = {name: torch.zeros(batch_size, length, dtype=torch.float32) for name in ("price", "price_missing", "time_seconds")}
    for row, item in enumerate(items):
        size = len(item.event_id)
        mask[row, :size] = True
        for name, tensor in integer_fields.items():
            tensor[row, :size] = torch.as_tensor(getattr(item, name))
        for name, tensor in float_fields.items():
            values = getattr(item, name)
            if name == "time_seconds":
                values = values - values[0]
            tensor[row, :size] = torch.as_tensor(values, dtype=torch.float32)
    return {
        **integer_fields,
        **float_fields,
        "mask": mask,
        "label": torch.tensor([item.label for item in items], dtype=torch.float32),
        "duration_seconds": torch.tensor([item.duration_seconds for item in items], dtype=torch.float32),
        "session_id": [item.session_id for item in items],
        "user_id": [item.user_id for item in items],
        "exact_signature": [item.exact_signature for item in items],
        "near_signature": [item.near_signature for item in items],
    }

