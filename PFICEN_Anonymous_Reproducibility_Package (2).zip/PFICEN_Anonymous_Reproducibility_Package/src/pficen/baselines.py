from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression


AGGREGATE_COLUMNS = (
    "prefix_length",
    "prefix_duration",
    "view_count",
    "cart_count",
    "remove_count",
    "view_fraction",
    "cart_fraction",
    "remove_fraction",
    "cart_present",
    "remove_present",
    "unique_products",
    "unique_categories",
    "unique_brands",
    "repeated_product_rate",
    "repeated_category_rate",
    "last_price",
    "mean_price",
    "std_price",
    "min_price",
    "max_price",
    "mean_gap",
    "std_gap",
    "min_gap",
    "max_gap",
    "recent_gap",
    "last_event_id",
)


def aggregate_prefix_features(events: pd.DataFrame, sessions: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for session_id, group in events.groupby("session_id", sort=False):
        group = group.sort_values("position", kind="stable")
        event = group["event_type"]
        price = pd.to_numeric(group["price"], errors="coerce")
        time = pd.to_datetime(group["event_time"], utc=True)
        gaps = time.diff().dt.total_seconds().dropna().clip(0)
        length = len(group)
        product_counts = group["product_id"].value_counts(dropna=True)
        category_counts = group["category_id"].value_counts(dropna=True)
        rows.append(
            {
                "session_id": session_id,
                "prefix_length": length,
                "prefix_duration": max(float((time.iloc[-1] - time.iloc[0]).total_seconds()), 0.0),
                "view_count": int((event == "view").sum()),
                "cart_count": int((event == "cart").sum()),
                "remove_count": int((event == "remove_from_cart").sum()),
                "view_fraction": float((event == "view").mean()),
                "cart_fraction": float((event == "cart").mean()),
                "remove_fraction": float((event == "remove_from_cart").mean()),
                "cart_present": int((event == "cart").any()),
                "remove_present": int((event == "remove_from_cart").any()),
                "unique_products": int(group["product_id"].nunique(dropna=True)),
                "unique_categories": int(group["category_id"].nunique(dropna=True)),
                "unique_brands": int(group["brand"].nunique(dropna=True)),
                "repeated_product_rate": float(product_counts[product_counts > 1].sum() / length) if length else 0.0,
                "repeated_category_rate": float(category_counts[category_counts > 1].sum() / length) if length else 0.0,
                "last_price": float(price.iloc[-1]) if pd.notna(price.iloc[-1]) else np.nan,
                "mean_price": float(price.mean()),
                "std_price": float(price.std(ddof=0)),
                "min_price": float(price.min()),
                "max_price": float(price.max()),
                "mean_gap": float(gaps.mean()) if len(gaps) else 0.0,
                "std_gap": float(gaps.std(ddof=0)) if len(gaps) else 0.0,
                "min_gap": float(gaps.min()) if len(gaps) else 0.0,
                "max_gap": float(gaps.max()) if len(gaps) else 0.0,
                "recent_gap": float(gaps.iloc[-1]) if len(gaps) else 0.0,
                "last_event_id": {"view": 0, "cart": 1, "remove_from_cart": 2}.get(str(event.iloc[-1]), 3),
            }
        )
    features = pd.DataFrame(rows).merge(sessions[["session_id", "user_id", "label"]], on="session_id", how="inner")
    return features


def build_baseline(name: str, parameters: dict):
    if name == "logistic_regression":
        return LogisticRegression(**parameters, solver="lbfgs", n_jobs=-1)
    if name == "random_forest":
        return RandomForestClassifier(**parameters, class_weight="balanced", n_jobs=-1, random_state=2026)
    if name == "xgboost":
        from xgboost import XGBClassifier

        return XGBClassifier(**parameters, objective="binary:logistic", eval_metric="aucpr", n_jobs=-1, random_state=2026)
    if name == "lightgbm":
        from lightgbm import LGBMClassifier

        return LGBMClassifier(**parameters, objective="binary", n_jobs=-1, random_state=2026)
    if name == "catboost":
        from catboost import CatBoostClassifier

        return CatBoostClassifier(**parameters, verbose=False, random_seed=2026)
    raise ValueError(f"baseline adapter is not available for {name}")


def fit_tabular_baseline(name: str, parameters: dict, train: pd.DataFrame, validation: pd.DataFrame):
    model = build_baseline(name, parameters)
    x_train = train[list(AGGREGATE_COLUMNS)].replace([np.inf, -np.inf], np.nan).fillna(0.0)
    x_validation = validation[list(AGGREGATE_COLUMNS)].replace([np.inf, -np.inf], np.nan).fillna(0.0)
    model.fit(x_train, train["label"])
    probabilities = model.predict_proba(x_validation)[:, 1]
    return model, probabilities

