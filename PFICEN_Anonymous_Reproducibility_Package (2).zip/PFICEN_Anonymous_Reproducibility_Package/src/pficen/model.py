from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn
from torch.nn import functional as F


class ContinuousTimeFunnelBlock(nn.Module):
    def __init__(self, hidden_dim: int = 128, heads: int = 8, feedforward_dim: int = 512, dropout: float = 0.1, time_bins: int = 16, use_time_bias: bool = True, use_funnel_bias: bool = True):
        super().__init__()
        if hidden_dim % heads:
            raise ValueError("hidden_dim must be divisible by heads")
        self.hidden_dim = hidden_dim
        self.heads = heads
        self.head_dim = hidden_dim // heads
        self.use_time_bias = use_time_bias
        self.use_funnel_bias = use_funnel_bias
        self.qkv = nn.Linear(hidden_dim, 3 * hidden_dim)
        self.output = nn.Linear(hidden_dim, hidden_dim)
        self.time_bias = nn.Embedding(time_bins, heads)
        self.funnel_bias = nn.Parameter(torch.zeros(heads, 3, 3))
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.norm2 = nn.LayerNorm(hidden_dim)
        self.feedforward = nn.Sequential(
            nn.Linear(hidden_dim, feedforward_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(feedforward_dim, hidden_dim),
        )
        self.dropout = nn.Dropout(dropout)
        boundaries = torch.linspace(0.0, torch.log1p(torch.tensor(24.0 * 3600.0)), time_bins + 1)[1:-1]
        self.register_buffer("time_boundaries", boundaries)

    def forward(self, x: torch.Tensor, event_id: torch.Tensor, time_seconds: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        batch, length, _ = x.shape
        residual = x
        x = self.norm1(x)
        qkv = self.qkv(x).view(batch, length, 3, self.heads, self.head_dim)
        q, k, v = qkv.unbind(dim=2)
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)
        logits = torch.matmul(q, k.transpose(-1, -2)) / (self.head_dim**0.5)

        pair_gap = (time_seconds[:, :, None] - time_seconds[:, None, :]).clamp(0.0, 24.0 * 3600.0)
        time_bin = torch.bucketize(torch.log1p(pair_gap), self.time_boundaries)
        if self.use_time_bias:
            logits = logits + self.time_bias(time_bin).permute(0, 3, 1, 2)

        valid_event = event_id.clamp(0, 2)
        src = valid_event[:, None, :, None].expand(batch, self.heads, length, length)
        dst = valid_event[:, None, None, :].expand(batch, self.heads, length, length)
        head = torch.arange(self.heads, device=x.device)[None, :, None, None].expand_as(src)
        funnel = self.funnel_bias[head, src, dst]
        supported = (event_id < 3)[:, None, :, None] & (event_id < 3)[:, None, None, :]
        if self.use_funnel_bias:
            logits = logits + funnel * supported

        causal = torch.tril(torch.ones(length, length, dtype=torch.bool, device=x.device))
        allowed = causal[None, None, :, :] & mask[:, None, None, :] & mask[:, None, :, None]
        logits = logits.masked_fill(~allowed, torch.finfo(logits.dtype).min)
        attention = torch.softmax(logits, dim=-1)
        attention = torch.nan_to_num(attention, nan=0.0)
        encoded = torch.matmul(self.dropout(attention), v).transpose(1, 2).reshape(batch, length, self.hidden_dim)
        x = residual + self.dropout(self.output(encoded))
        x = x + self.dropout(self.feedforward(self.norm2(x)))
        return x * mask.unsqueeze(-1)


class AttentionPool(nn.Module):
    def __init__(self, hidden_dim: int):
        super().__init__()
        self.score = nn.Linear(hidden_dim, 1, bias=False)

    def forward(self, states: torch.Tensor, mask: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        logits = self.score(states).squeeze(-1).masked_fill(~mask, torch.finfo(states.dtype).min)
        weights = torch.softmax(logits, dim=-1)
        vector = torch.sum(weights.unsqueeze(-1) * states, dim=1)
        return vector, weights


class SparseExpertLayer(nn.Module):
    def __init__(self, hidden_dim: int, expert_hidden_dim: int = 256, experts: int = 4, active: int = 2, dropout: float = 0.1):
        super().__init__()
        self.active = active
        self.gate = nn.Linear(hidden_dim, experts)
        self.experts = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(hidden_dim, expert_hidden_dim),
                    nn.GELU(),
                    nn.Dropout(dropout),
                    nn.Linear(expert_hidden_dim, hidden_dim),
                )
                for _ in range(experts)
            ]
        )

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        weights = torch.softmax(self.gate(x), dim=-1)
        top_weights, top_index = torch.topk(weights, k=self.active, dim=-1)
        top_weights = top_weights / top_weights.sum(dim=-1, keepdim=True)
        outputs = torch.stack([expert(x) for expert in self.experts], dim=1)
        selected = torch.gather(outputs, 1, top_index.unsqueeze(-1).expand(-1, -1, x.shape[-1]))
        fused = torch.sum(top_weights.unsqueeze(-1) * selected, dim=1)
        sparse = torch.zeros_like(weights).scatter(1, top_index, top_weights)
        return fused, sparse


@dataclass
class PFICENOutput:
    logits: torch.Tensor
    session_vector: torch.Tensor
    position_logits: torch.Tensor
    routing_weights: torch.Tensor
    pooling_weights: torch.Tensor


class PFICEN(nn.Module):
    def __init__(
        self,
        vocabulary_sizes: dict[str, int],
        hidden_dim: int = 128,
        encoder_layers: int = 3,
        context_layers: int = 2,
        attention_heads: int = 8,
        feedforward_dim: int = 512,
        dropout: float = 0.1,
        experts: int = 4,
        active_experts: int = 2,
        expert_hidden_dim: int = 256,
        max_events: int = 64,
        time_bins: int = 16,
        use_time_bias: bool = True,
        use_funnel_bias: bool = True,
        use_experts: bool = True,
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.event_embedding = nn.Embedding(4, hidden_dim)
        self.product_embedding = nn.Embedding(vocabulary_sizes["product"], hidden_dim, padding_idx=0)
        self.category_embedding = nn.Embedding(vocabulary_sizes["category"], hidden_dim, padding_idx=0)
        self.brand_embedding = nn.Embedding(vocabulary_sizes["brand"], hidden_dim, padding_idx=0)
        self.position_embedding = nn.Embedding(max_events, hidden_dim)
        self.gap_embedding = nn.Embedding(time_bins, hidden_dim)
        self.numeric_projection = nn.Linear(2, hidden_dim)
        self.use_experts = use_experts
        self.encoder = nn.ModuleList(
            [ContinuousTimeFunnelBlock(hidden_dim, attention_heads, feedforward_dim, dropout, time_bins, use_time_bias, use_funnel_bias) for _ in range(encoder_layers)]
        )
        self.pool = AttentionPool(hidden_dim)
        context_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=attention_heads,
            dim_feedforward=feedforward_dim,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.context_transformer = nn.TransformerEncoder(context_layer, num_layers=context_layers)
        self.label_embedding = nn.Embedding(2, hidden_dim)
        self.expert_layer = SparseExpertLayer(hidden_dim, expert_hidden_dim, experts, active_experts, dropout)
        self.single_path = nn.Sequential(nn.Linear(hidden_dim, expert_hidden_dim), nn.GELU(), nn.Dropout(dropout), nn.Linear(expert_hidden_dim, hidden_dim))
        self.head = nn.Linear(hidden_dim, 1)
        self.position_head = nn.Linear(hidden_dim, 1)
        boundaries = torch.linspace(0.0, torch.log1p(torch.tensor(24.0 * 3600.0)), time_bins + 1)[1:-1]
        self.register_buffer("gap_boundaries", boundaries)

    def encode(self, batch: dict[str, torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        mask = batch["mask"]
        batch_size, length = mask.shape
        position = torch.arange(length, device=mask.device)[None, :].expand(batch_size, -1)
        gap = (batch["time_seconds"][:, 1:] - batch["time_seconds"][:, :-1]).clamp(0, 24 * 3600)
        gap = F.pad(gap, (1, 0))
        gap_bin = torch.bucketize(torch.log1p(gap), self.gap_boundaries)
        numeric = torch.stack((batch["price"], batch["price_missing"]), dim=-1)
        states = (
            self.event_embedding(batch["event_id"])
            + self.product_embedding(batch["product"])
            + self.category_embedding(batch["category"])
            + self.brand_embedding(batch["brand"])
            + self.position_embedding(position)
            + self.gap_embedding(gap_bin)
            + self.numeric_projection(numeric)
        )
        for block in self.encoder:
            states = block(states, batch["event_id"], batch["time_seconds"], mask)
        session, pooling = self.pool(states, mask)
        return states, F.normalize(session, dim=-1), pooling

    def forward(
        self,
        batch: dict[str, torch.Tensor],
        context_vectors: torch.Tensor | None = None,
        context_labels: torch.Tensor | None = None,
    ) -> PFICENOutput:
        states, session, pooling = self.encode(batch)
        if context_vectors is None or context_labels is None:
            contextual = session
        else:
            context_tokens = context_vectors.detach() + self.label_embedding(context_labels.long())
            tokens = torch.cat((session.unsqueeze(1), context_tokens), dim=1)
            contextual = self.context_transformer(tokens)[:, 0]
        if self.use_experts:
            fused, routing = self.expert_layer(contextual)
        else:
            fused = self.single_path(contextual)
            routing = torch.ones(contextual.shape[0], 1, device=contextual.device, dtype=contextual.dtype)
        logits = self.head(fused).squeeze(-1)
        position_logits = self.position_head(states).squeeze(-1)
        return PFICENOutput(logits, session, position_logits, routing, pooling)

