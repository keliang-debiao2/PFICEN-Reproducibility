from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from .calibration import TemperatureScaler, select_f1_threshold
from .losses import combined_loss
from .metrics import classification_metrics
from .retrieval import LabelStratifiedRetriever, RetrievalMetadata


def _device_batch(batch: dict, device: torch.device) -> dict:
    return {key: value.to(device) if torch.is_tensor(value) else value for key, value in batch.items()}


def _query_metadata(batch: dict) -> list[dict[str, object]]:
    return [
        {
            "session_id": batch["session_id"][index],
            "user_id": batch["user_id"][index],
            "exact_signature": batch["exact_signature"][index],
            "near_signature": batch["near_signature"][index],
            "duration_seconds": float(batch["duration_seconds"][index]),
        }
        for index in range(len(batch["session_id"]))
    ]


@dataclass
class PredictionBundle:
    logits: np.ndarray
    labels: np.ndarray
    session_id: np.ndarray
    user_id: np.ndarray


@torch.no_grad()
def encode_loader(model, loader: DataLoader, device: torch.device):
    model.eval()
    vectors = []
    labels = []
    metadata = {name: [] for name in ("session_id", "user_id", "exact_signature", "near_signature", "duration_seconds")}
    for batch in loader:
        moved = _device_batch(batch, device)
        _, session, _ = model.encode(moved)
        vectors.append(session.cpu().numpy())
        labels.append(moved["label"].cpu().numpy().astype(np.int8))
        for name in metadata:
            values = batch[name]
            metadata[name].extend(values.tolist() if torch.is_tensor(values) else values)
    retrieval_metadata = RetrievalMetadata(
        session_id=np.asarray(metadata["session_id"], dtype=object),
        user_id=np.asarray(metadata["user_id"], dtype=object),
        exact_signature=np.asarray(metadata["exact_signature"], dtype=object),
        near_signature=np.asarray(metadata["near_signature"], dtype=object),
        duration_seconds=np.asarray(metadata["duration_seconds"], dtype=np.float64),
    )
    return np.concatenate(vectors), np.concatenate(labels), retrieval_metadata


@torch.no_grad()
def predict(model, loader: DataLoader, device: torch.device, retriever: LabelStratifiedRetriever | None = None) -> PredictionBundle:
    model.eval()
    logits, labels, session_id, user_id = [], [], [], []
    for batch in loader:
        moved = _device_batch(batch, device)
        context_vectors = context_labels = None
        if retriever is not None:
            _, query_vectors, _ = model.encode(moved)
            vectors, retrieved_labels = retriever.retrieve(query_vectors.cpu().numpy(), _query_metadata(batch))
            context_vectors = torch.as_tensor(vectors, dtype=torch.float32, device=device)
            context_labels = torch.as_tensor(retrieved_labels, dtype=torch.long, device=device)
        output = model(moved, context_vectors, context_labels)
        logits.append(output.logits.cpu().numpy())
        labels.append(moved["label"].cpu().numpy())
        session_id.extend(batch["session_id"])
        user_id.extend(batch["user_id"])
    return PredictionBundle(np.concatenate(logits), np.concatenate(labels), np.asarray(session_id), np.asarray(user_id))


def train_model(
    model,
    train_loader: DataLoader,
    validation_loader: DataLoader,
    config: dict,
    output_dir: str | Path,
    device: str | torch.device = "cuda" if torch.cuda.is_available() else "cpu",
):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(device)
    model.to(device)
    optimization = config["optimization"]
    retrieval_config = config["retrieval"]
    optimizer = torch.optim.AdamW(model.parameters(), lr=optimization["learning_rate"], weight_decay=optimization["weight_decay"])
    retriever = LabelStratifiedRetriever(
        dimension=retrieval_config["dimension"],
        nlist=retrieval_config["nlist"],
        nprobe=retrieval_config["nprobe"],
        fallback_nprobe=retrieval_config["fallback_nprobe"],
        initial_candidates=retrieval_config["initial_candidates_per_label"],
        fallback_candidates=retrieval_config["fallback_candidates_per_label"],
        contexts_per_label=retrieval_config["positive_contexts"],
        near_duration_ratio=retrieval_config["near_duplicate_duration_ratio"],
    )
    best_pr_auc = -np.inf
    best_ece = np.inf
    epochs_without_improvement = 0
    trace_path = output_dir / "training.jsonl"
    for epoch in range(optimization["epochs"]):
        epoch_start = time.perf_counter()
        retrieval_active = retrieval_config.get("enabled", True) and epoch >= retrieval_config["warmup_epochs"]
        if retrieval_active:
            vectors, labels, metadata = encode_loader(model, train_loader, device)
            retriever.build(vectors, labels, metadata)
        model.train()
        epoch_losses = []
        for batch in train_loader:
            moved = _device_batch(batch, device)
            context_vectors = context_labels = None
            if retrieval_active:
                with torch.no_grad():
                    _, query_vectors, _ = model.encode(moved)
                vectors, retrieved_labels = retriever.retrieve(query_vectors.cpu().numpy(), _query_metadata(batch))
                context_vectors = torch.as_tensor(vectors, dtype=torch.float32, device=device)
                context_labels = torch.as_tensor(retrieved_labels, dtype=torch.long, device=device)
            optimizer.zero_grad(set_to_none=True)
            output = model(moved, context_vectors, context_labels)
            loss, components = combined_loss(
                output,
                moved,
                context_vectors,
                context_labels,
                lambda_retrieval=optimization["lambda_retrieval"],
                lambda_funnel=optimization["lambda_funnel"],
                lambda_diversity=optimization["lambda_diversity"],
                lambda_calibration=optimization["lambda_calibration"],
                retrieval_temperature=optimization["retrieval_temperature"],
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), optimization["gradient_clip"])
            optimizer.step()
            epoch_losses.append(components)
        validation = predict(model, validation_loader, device, retriever if retrieval_active else None)
        scaler = TemperatureScaler().fit(validation.logits, validation.labels)
        probabilities = scaler.predict_proba(validation.logits)
        threshold = select_f1_threshold(validation.labels, probabilities)
        metrics = classification_metrics(validation.labels, probabilities, threshold, config["calibration"]["ece_bins"])
        record = {
            "epoch": epoch + 1,
            "retrieval_active": retrieval_active,
            "mean_total_loss": float(np.mean([entry["total"] for entry in epoch_losses])),
            "validation": metrics,
            "temperature": scaler.temperature,
            "threshold": threshold,
            "elapsed_seconds": time.perf_counter() - epoch_start,
        }
        with trace_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, sort_keys=True) + "\n")
        improved = metrics["pr_auc"] > best_pr_auc or (metrics["pr_auc"] == best_pr_auc and metrics["ece"] < best_ece)
        if improved:
            best_pr_auc, best_ece = metrics["pr_auc"], metrics["ece"]
            epochs_without_improvement = 0
            torch.save({"model": model.state_dict(), "epoch": epoch + 1, "temperature": scaler.temperature, "threshold": threshold, "metrics": metrics}, output_dir / "best_checkpoint.pt")
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= optimization["patience"]:
                break
    checkpoint = torch.load(output_dir / "best_checkpoint.pt", map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model"])
    if retrieval_config.get("enabled", True):
        vectors, labels, metadata = encode_loader(model, train_loader, device)
        retriever.build(vectors, labels, metadata)
        final_retriever = retriever
    else:
        final_retriever = None
    return model, final_retriever, checkpoint

