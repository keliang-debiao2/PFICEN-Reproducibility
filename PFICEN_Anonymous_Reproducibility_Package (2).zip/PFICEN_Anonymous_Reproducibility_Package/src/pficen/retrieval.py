from __future__ import annotations

from dataclasses import dataclass

import numpy as np

try:
    import faiss
except ImportError:
    faiss = None


@dataclass
class RetrievalMetadata:
    session_id: np.ndarray
    user_id: np.ndarray
    exact_signature: np.ndarray
    near_signature: np.ndarray
    duration_seconds: np.ndarray


class LabelIndex:
    def __init__(self, dimension: int, nlist: int = 4096, nprobe: int = 32):
        if faiss is None:
            raise ImportError("faiss-cpu is required for retrieval")
        self.dimension = dimension
        self.requested_nlist = nlist
        self.nprobe = nprobe
        self.index = None
        self.vectors = np.empty((0, dimension), dtype=np.float32)
        self.metadata: RetrievalMetadata | None = None

    def build(self, vectors: np.ndarray, metadata: RetrievalMetadata) -> None:
        vectors = np.ascontiguousarray(vectors, dtype=np.float32)
        faiss.normalize_L2(vectors)
        self.vectors = vectors.astype(np.float16)
        self.metadata = metadata
        if len(vectors) < max(256, self.requested_nlist * 4):
            self.index = faiss.IndexFlatIP(self.dimension)
        else:
            nlist = min(self.requested_nlist, max(1, len(vectors) // 4))
            quantizer = faiss.IndexFlatIP(self.dimension)
            self.index = faiss.IndexIVFFlat(quantizer, self.dimension, nlist, faiss.METRIC_INNER_PRODUCT)
            self.index.train(vectors)
            self.index.nprobe = min(self.nprobe, nlist)
        self.index.add(vectors)

    def search(self, query: np.ndarray, k: int, nprobe: int | None = None) -> np.ndarray:
        if self.index is None:
            raise RuntimeError("index has not been built")
        query = np.ascontiguousarray(query, dtype=np.float32)
        faiss.normalize_L2(query)
        if hasattr(self.index, "nprobe") and nprobe is not None:
            self.index.nprobe = min(nprobe, self.index.nlist)
        _, indices = self.index.search(query, min(k, self.index.ntotal))
        return indices


class LabelStratifiedRetriever:
    def __init__(
        self,
        dimension: int = 128,
        nlist: int = 4096,
        nprobe: int = 32,
        fallback_nprobe: int = 64,
        initial_candidates: int = 256,
        fallback_candidates: int = 1024,
        contexts_per_label: int = 32,
        near_duration_ratio: float = 0.05,
    ):
        self.positive = LabelIndex(dimension, nlist, nprobe)
        self.negative = LabelIndex(dimension, nlist, nprobe)
        self.nprobe = nprobe
        self.fallback_nprobe = fallback_nprobe
        self.initial_candidates = initial_candidates
        self.fallback_candidates = fallback_candidates
        self.contexts_per_label = contexts_per_label
        self.near_duration_ratio = near_duration_ratio

    @staticmethod
    def _subset_metadata(metadata: RetrievalMetadata, mask: np.ndarray) -> RetrievalMetadata:
        return RetrievalMetadata(*(getattr(metadata, field)[mask] for field in metadata.__dataclass_fields__))

    def build(self, vectors: np.ndarray, labels: np.ndarray, metadata: RetrievalMetadata) -> None:
        labels = np.asarray(labels, dtype=np.int8)
        positive = labels == 1
        negative = labels == 0
        if not positive.any() or not negative.any():
            raise ValueError("both labels are required to build stratified indexes")
        self.positive.build(vectors[positive], self._subset_metadata(metadata, positive))
        self.negative.build(vectors[negative], self._subset_metadata(metadata, negative))

    def _eligible(self, index: LabelIndex, candidates: np.ndarray, query: dict[str, object]) -> list[int]:
        metadata = index.metadata
        if metadata is None:
            raise RuntimeError("metadata is unavailable")
        selected: list[int] = []
        for candidate in candidates:
            candidate = int(candidate)
            if candidate < 0:
                continue
            if str(metadata.session_id[candidate]) == str(query["session_id"]):
                continue
            if str(metadata.user_id[candidate]) == str(query["user_id"]):
                continue
            if str(metadata.exact_signature[candidate]) == str(query["exact_signature"]):
                continue
            same_near = str(metadata.near_signature[candidate]) == str(query["near_signature"])
            query_duration = max(float(query["duration_seconds"]), 1.0)
            close_duration = abs(float(metadata.duration_seconds[candidate]) - query_duration) <= self.near_duration_ratio * query_duration
            if same_near and close_duration:
                continue
            selected.append(candidate)
            if len(selected) == self.contexts_per_label:
                break
        return selected

    def _retrieve_label(self, index: LabelIndex, query_vector: np.ndarray, query_metadata: dict[str, object]) -> np.ndarray:
        first = index.search(query_vector[None, :], self.initial_candidates, self.nprobe)[0]
        chosen = self._eligible(index, first, query_metadata)
        if len(chosen) < self.contexts_per_label:
            second = index.search(query_vector[None, :], self.fallback_candidates, self.fallback_nprobe)[0]
            chosen = self._eligible(index, second, query_metadata)
        if len(chosen) < self.contexts_per_label:
            raise RuntimeError("insufficient eligible contexts after fallback search")
        return index.vectors[np.asarray(chosen)].astype(np.float32)

    def retrieve(self, query_vectors: np.ndarray, query_metadata: list[dict[str, object]]) -> tuple[np.ndarray, np.ndarray]:
        contexts = []
        labels = []
        for vector, metadata in zip(query_vectors, query_metadata, strict=True):
            positive = self._retrieve_label(self.positive, vector, metadata)
            negative = self._retrieve_label(self.negative, vector, metadata)
            contexts.append(np.concatenate((positive, negative), axis=0))
            labels.append(np.concatenate((np.ones(len(positive)), np.zeros(len(negative)))).astype(np.int64))
        return np.stack(contexts), np.stack(labels)

