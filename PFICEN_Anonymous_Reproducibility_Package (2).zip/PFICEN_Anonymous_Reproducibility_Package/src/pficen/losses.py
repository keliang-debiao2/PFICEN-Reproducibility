from __future__ import annotations

import torch
from torch.nn import functional as F


TRANSITION_MARGIN = torch.tensor(
    [
        [0.000, 0.020, 0.000],
        [-0.010, 0.000, -0.030],
        [0.000, 0.020, 0.000],
    ],
    dtype=torch.float32,
)


def class_balanced_bce(logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    positive = labels.sum().clamp_min(1.0)
    negative = (1.0 - labels).sum().clamp_min(1.0)
    total = positive + negative
    weights = torch.where(labels > 0.5, total / (2 * positive), total / (2 * negative))
    return F.binary_cross_entropy_with_logits(logits, labels, weight=weights)


def retrieval_consistency_loss(
    logits: torch.Tensor,
    query_vectors: torch.Tensor,
    context_vectors: torch.Tensor,
    context_labels: torch.Tensor,
    temperature: float = 0.10,
) -> torch.Tensor:
    similarity = F.cosine_similarity(query_vectors[:, None, :], context_vectors, dim=-1)
    weights = torch.softmax(similarity / temperature, dim=-1).detach()
    target = torch.sum(weights * context_labels.float(), dim=-1).clamp(1e-5, 1 - 1e-5)
    return F.binary_cross_entropy_with_logits(logits, target)


def funnel_consistency_loss(position_logits: torch.Tensor, event_id: torch.Tensor, mask: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    if position_logits.shape[1] < 2:
        return position_logits.sum() * 0.0
    current = position_logits[:, 1:]
    previous = position_logits[:, :-1]
    source = event_id[:, :-1].clamp(0, 2)
    destination = event_id[:, 1:].clamp(0, 2)
    margin_table = TRANSITION_MARGIN.to(position_logits.device)
    margin = margin_table[source, destination]
    valid = mask[:, 1:] & mask[:, :-1] & (event_id[:, 1:] < 3) & (event_id[:, :-1] < 3) & (labels[:, None] > 0.5)
    violation = F.relu(previous + margin - current)
    return violation[valid].mean() if valid.any() else position_logits.sum() * 0.0


def expert_diversity_loss(routing_weights: torch.Tensor) -> torch.Tensor:
    mean_usage = routing_weights.mean(dim=0)
    target = torch.full_like(mean_usage, 1.0 / mean_usage.numel())
    return torch.sum((mean_usage - target) ** 2)


def brier_loss(logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    return torch.mean((torch.sigmoid(logits) - labels) ** 2)


def combined_loss(
    output,
    batch: dict[str, torch.Tensor],
    context_vectors: torch.Tensor | None,
    context_labels: torch.Tensor | None,
    lambda_retrieval: float = 0.10,
    lambda_funnel: float = 0.05,
    lambda_diversity: float = 0.01,
    lambda_calibration: float = 0.20,
    retrieval_temperature: float = 0.10,
) -> tuple[torch.Tensor, dict[str, float]]:
    main = class_balanced_bce(output.logits, batch["label"])
    retrieval = output.logits.sum() * 0.0 if context_labels is None or context_vectors is None else retrieval_consistency_loss(output.logits, output.session_vector, context_vectors, context_labels, retrieval_temperature)
    funnel = funnel_consistency_loss(output.position_logits, batch["event_id"], batch["mask"], batch["label"])
    diversity = expert_diversity_loss(output.routing_weights)
    calibration = brier_loss(output.logits, batch["label"])
    total = main + lambda_retrieval * retrieval + lambda_funnel * funnel + lambda_diversity * diversity + lambda_calibration * calibration
    components = {name: float(value.detach().cpu()) for name, value in {"main": main, "retrieval": retrieval, "funnel": funnel, "diversity": diversity, "calibration": calibration, "total": total}.items()}
    return total, components

