from __future__ import annotations

from collections.abc import Callable

import numpy as np

from .utils import stable_hash


def deterministic_context_indices(labels: np.ndarray, rows: int, seed: int, preserve_prevalence: bool = True) -> np.ndarray:
    labels = np.asarray(labels, dtype=np.int8)
    if rows > len(labels):
        raise ValueError("requested context is larger than the training partition")
    if not preserve_prevalence:
        order = np.argsort([stable_hash(index, seed) for index in range(len(labels))], kind="stable")
        return order[:rows]
    positive_target = int(round(rows * float(np.mean(labels == 1))))
    targets = {1: positive_target, 0: rows - positive_target}
    selected = []
    for label in (0, 1):
        members = np.flatnonzero(labels == label)
        target = targets[label]
        order = np.argsort([stable_hash(int(index), seed) for index in members], kind="stable")
        selected.extend(members[order[:target]].tolist())
    if len(selected) < rows:
        remaining = np.setdiff1d(np.arange(len(labels)), np.asarray(selected), assume_unique=False)
        order = np.argsort([stable_hash(int(index), seed + 1) for index in remaining], kind="stable")
        selected.extend(remaining[order[: rows - len(selected)]].tolist())
    return np.asarray(selected[:rows], dtype=np.int64)


class ContextEnsembleAdapter:
    def __init__(
        self,
        predictor: Callable[[np.ndarray, np.ndarray, np.ndarray], np.ndarray],
        contexts: int,
        rows_per_context: int,
        base_seed: int,
    ):
        self.predictor = predictor
        self.contexts = contexts
        self.rows_per_context = rows_per_context
        self.base_seed = base_seed

    def predict_logits(self, x_train: np.ndarray, y_train: np.ndarray, x_query: np.ndarray) -> np.ndarray:
        logits = []
        for context in range(self.contexts):
            indices = deterministic_context_indices(y_train, self.rows_per_context, self.base_seed + context, preserve_prevalence=True)
            logits.append(np.asarray(self.predictor(x_train[indices], y_train[indices], x_query), dtype=np.float64))
        return np.mean(np.stack(logits), axis=0)


def tabpfn3_adapter(predictor: Callable, base_seed: int = 2026) -> ContextEnsembleAdapter:
    return ContextEnsembleAdapter(predictor, contexts=4, rows_per_context=8192, base_seed=base_seed)


def tabfm_adapter(predictor: Callable, base_seed: int = 2026) -> ContextEnsembleAdapter:
    return ContextEnsembleAdapter(predictor, contexts=8, rows_per_context=8192, base_seed=base_seed)

