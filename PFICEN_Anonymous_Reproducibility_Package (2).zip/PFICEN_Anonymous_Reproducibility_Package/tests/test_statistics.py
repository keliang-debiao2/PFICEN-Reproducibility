import numpy as np

from pficen.statistics import holm_adjust, paired_bootstrap


def test_holm_adjustment_is_bounded_and_ordered():
    adjusted = holm_adjust([0.01, 0.04, 0.02])
    assert all(0 <= value <= 1 for value in adjusted)
    assert adjusted[0] <= adjusted[2] <= adjusted[1]


def test_clustered_bootstrap_returns_interval():
    labels = np.array([0, 1, 0, 1, 0, 1, 0, 1])
    first = np.array([0.1, 0.9, 0.2, 0.8, 0.3, 0.7, 0.4, 0.6])
    second = np.array([0.3, 0.7, 0.4, 0.6, 0.45, 0.55, 0.49, 0.51])
    clusters = np.array([1, 1, 2, 2, 3, 3, 4, 4])
    result = paired_bootstrap(labels, first, second, clusters, replicates=100, seed=9)
    assert result["ci_lower"] <= result["difference"] <= result["ci_upper"]

