import pandas as pd

from pficen.protocols import clean_events, construct_fifth_event, construct_outcome_aligned, positive_prefix_lengths


def event_frame():
    rows = [
        ("2019-10-01T00:00:00Z", "view", 1, 10, "a", 2.0, 100, "s1"),
        ("2019-10-01T00:01:00Z", "cart", 1, 10, "a", 2.0, 100, "s1"),
        ("2019-10-01T00:02:00Z", "view", 2, 11, "b", 3.0, 100, "s1"),
        ("2019-10-01T00:03:00Z", "cart", 2, 11, "b", 3.0, 100, "s1"),
        ("2019-10-01T00:04:00Z", "view", 3, 12, "c", 4.0, 100, "s1"),
        ("2019-10-01T00:10:00Z", "purchase", 3, 12, "c", 4.0, 100, "s1"),
        ("2019-10-02T00:00:00Z", "view", 4, 13, "d", 5.0, 200, "s2"),
        ("2019-10-02T00:01:00Z", "view", 5, 13, "d", 5.0, 200, "s2"),
        ("2019-10-02T00:02:00Z", "view", 6, 13, "d", 5.0, 200, "s2"),
        ("2019-10-02T00:03:00Z", "view", 7, 13, "d", 5.0, 200, "s2"),
        ("2019-10-02T00:04:00Z", "view", 8, 13, "d", 5.0, 200, "s2"),
    ]
    return pd.DataFrame(rows, columns=["event_time", "event_type", "product_id", "category_id", "brand", "price", "user_id", "user_session"])


def test_fifth_event_horizon_and_prefix_length():
    clean, _ = clean_events(event_frame())
    records = construct_fifth_event(clean, 5, 30)
    assert len(records) == 2
    assert all(len(record.events) == 5 for record in records)
    assert {record.label for record in records} == {0, 1}


def test_outcome_aligned_excludes_purchase():
    clean, _ = clean_events(event_frame())
    lengths = positive_prefix_lengths(clean)
    records = construct_outcome_aligned(clean, lengths, max_events=64, lookback_hours=24)
    positive = next(record for record in records if record.label == 1)
    assert "purchase" not in positive.events["event_type"].tolist()
    assert len(positive.events) == 5

