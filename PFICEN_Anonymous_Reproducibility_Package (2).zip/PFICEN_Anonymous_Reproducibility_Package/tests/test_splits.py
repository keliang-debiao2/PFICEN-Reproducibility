import pandas as pd

from pficen.splits import outer_user_folds


def test_outer_folds_are_user_disjoint():
    rows = []
    for user in range(40):
        for session in range(2):
            rows.append({"user_id": f"u{user}", "session_id": f"s{user}_{session}", "label": int(user % 5 == 0)})
    frame = pd.DataFrame(rows)
    frame["fold"] = outer_user_folds(frame, 5, 2026)
    assert frame.groupby("user_id")["fold"].nunique().max() == 1
    assert set(frame["fold"]) == {0, 1, 2, 3, 4}

