import torch

from pficen.losses import funnel_consistency_loss


def test_negative_sessions_do_not_enter_funnel_loss():
    logits = torch.tensor([[0.0, -1.0, -2.0]])
    events = torch.tensor([[0, 1, 0]])
    mask = torch.ones_like(events, dtype=torch.bool)
    labels = torch.tensor([0.0])
    assert float(funnel_consistency_loss(logits, events, mask, labels)) == 0.0


def test_positive_view_to_cart_margin_penalizes_drop():
    logits = torch.tensor([[0.0, -0.5]])
    events = torch.tensor([[0, 1]])
    mask = torch.ones_like(events, dtype=torch.bool)
    labels = torch.tensor([1.0])
    assert float(funnel_consistency_loss(logits, events, mask, labels)) > 0.0

