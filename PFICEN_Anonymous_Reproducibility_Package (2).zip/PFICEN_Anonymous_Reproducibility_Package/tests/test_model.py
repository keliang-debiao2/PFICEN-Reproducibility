import torch

from pficen.model import PFICEN


def make_batch(batch_size=3, length=5):
    return {
        "event_id": torch.randint(0, 3, (batch_size, length)),
        "product": torch.randint(3, 20, (batch_size, length)),
        "category": torch.randint(3, 15, (batch_size, length)),
        "brand": torch.randint(3, 12, (batch_size, length)),
        "price": torch.randn(batch_size, length),
        "price_missing": torch.zeros(batch_size, length),
        "time_seconds": torch.arange(length).float()[None, :].repeat(batch_size, 1),
        "mask": torch.ones(batch_size, length, dtype=torch.bool),
        "label": torch.tensor([0.0, 1.0, 0.0]),
    }


def test_forward_shapes_and_sparse_routing():
    model = PFICEN({"product": 20, "category": 15, "brand": 12}, encoder_layers=1, context_layers=1, max_events=5)
    batch = make_batch()
    context = torch.randn(3, 64, 128)
    labels = torch.cat((torch.ones(3, 32), torch.zeros(3, 32)), dim=1).long()
    output = model(batch, context, labels)
    assert output.logits.shape == (3,)
    assert output.position_logits.shape == (3, 5)
    assert torch.all((output.routing_weights > 0).sum(dim=1) == 2)
    assert torch.allclose(output.routing_weights.sum(dim=1), torch.ones(3), atol=1e-6)


def test_causal_prefix_state_is_future_invariant():
    torch.manual_seed(7)
    model = PFICEN({"product": 20, "category": 15, "brand": 12}, encoder_layers=1, context_layers=1, max_events=5, dropout=0.0).eval()
    first = make_batch(batch_size=3, length=5)
    second = {key: value.clone() if torch.is_tensor(value) else value for key, value in first.items()}
    second["product"][:, 4] = 19
    with torch.no_grad():
        first_states, _, _ = model.encode(first)
        second_states, _, _ = model.encode(second)
    assert torch.allclose(first_states[:, :4], second_states[:, :4], atol=1e-5)

