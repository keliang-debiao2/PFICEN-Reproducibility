# PFICEN Anonymous Reproducibility Package

This repository contains the anonymous implementation and evaluation workflow for **Funnel-Aware In-Context Expert Learning for Online Purchase Conversion Prediction Under Product-Domain Shift**.

The package covers deterministic data construction, user-grouped validation, chronological confirmation, fold-specific preprocessing, leakage-controlled FAISS retrieval, PFICEN training, calibration, baseline evaluation, external transfer, ablation, controlled perturbations, paired bootstrap inference, and efficiency reporting.

## Repository map

```text
configs/                 Fixed experiment configurations
docs/                    Protocol, schema, method mapping, and provenance notes
logs/reference_runs/     Manuscript-aligned reference run records
results/reference/       Machine-readable reported result tables
scripts/                 Command-line experiment entry points
src/pficen/              Model and evaluation implementation
tests/                   Deterministic unit and integration checks
```

## Data files

Download the public REES46 files described in `docs/DATA_SCHEMA.md` and place them under a local data directory. Raw files are not redistributed in this repository.

Development source:

- REES46 multi-category e-commerce behavior data, October and November 2019.

External source:

- REES46 cosmetics-shop event history, October 2019 through February 2020.

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .[full]
```

The environment can also be created from `environment.yml`.

## Validation

```bash
python scripts/validate_repository.py
pytest -q
```

## Data preparation

```bash
python scripts/prepare_data.py \
  --config configs/outcome_aligned.yaml \
  --raw-dir /path/to/development/raw \
  --output-dir /path/to/work/development

python scripts/prepare_data.py \
  --config configs/fifth_event.yaml \
  --raw-dir /path/to/development/raw \
  --output-dir /path/to/work/development_fifth_event
```

## Five-fold PFICEN run

```bash
python scripts/run_cross_validation.py \
  --config configs/outcome_aligned.yaml \
  --data-dir /path/to/work/development \
  --output-dir runs/outcome_aligned
```

## External evaluation

```bash
python scripts/run_external.py \
  --config configs/external.yaml \
  --development-run runs/outcome_aligned \
  --development-data-dir /path/to/work/development \
  --external-data-dir /path/to/work/external \
  --output-dir runs/external
```

The label-independent external run uses `configs/external_fifth_event.yaml` together with `configs/fifth_event.yaml` and the corresponding fifth-event development run.

## Chronological confirmation

```bash
python scripts/run_temporal.py \
  --config configs/fifth_event.yaml \
  --data-dir /path/to/work/development_fifth_event \
  --output-dir runs/temporal
```

## Additional analyses

```bash
python scripts/run_baselines.py --config configs/baselines.yaml --data-dir /path/to/work/development --output-dir runs/baselines
python scripts/run_ablation.py --config configs/ablation.yaml --data-dir /path/to/work/development --output-dir runs/ablation
python scripts/run_robustness.py --config configs/robustness.yaml --data-dir /path/to/work/development --base-run runs/outcome_aligned --output-dir runs/robustness
python scripts/run_statistics.py --run-dir runs/outcome_aligned --output-dir runs/statistics
python scripts/run_efficiency.py --config configs/outcome_aligned.yaml --data-dir /path/to/work/development --output-dir runs/efficiency
```

`scripts/reproduce_all.py` executes the configured workflow in dependency order. Large public datasets require substantial storage and compute, so each stage supports resumable outputs.

After a completed run, `scripts/compare_to_reference.py` compares the generated fold summary with the manuscript-aligned targets under a user-specified absolute tolerance.

## Leakage controls

- `user_id` is the outer-fold grouping unit.
- All vocabularies and numerical transformations are fitted on the current outer-training users only.
- The retrieval bank contains only current outer-training sessions.
- Query session, same-user sessions, exact duplicates, and prespecified near duplicates are excluded before context selection.
- Calibration and F1 thresholds are fitted on inner-validation users only.
- External data do not update model parameters, retrieval indexes, vocabularies, scalers, temperatures, or thresholds.

## Reference records

The files in `logs/reference_runs/` and `results/reference/` preserve the manuscript-reported targets and expected record structure. Their provenance and permitted use are defined in `docs/RESULT_PROVENANCE.md`.

## Anonymous review status

No author name, affiliation, email address, local workstation path, repository account, or personal identifier is included. See `docs/ANONYMITY.md`.

