#!/usr/bin/env python
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def run(command: list[str]) -> None:
    subprocess.run(command, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Execute the configured PFICEN workflow")
    parser.add_argument("--development-raw", required=True)
    parser.add_argument("--external-raw", required=True)
    parser.add_argument("--work-dir", required=True)
    parser.add_argument("--seed", type=int)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    work = Path(args.work_dir)
    work.mkdir(parents=True, exist_ok=True)
    development = work / "development"
    external = work / "external"
    run([sys.executable, str(root / "scripts" / "prepare_data.py"), "--config", str(root / "configs" / "outcome_aligned.yaml"), "--raw-dir", args.development_raw, "--output-dir", str(development)])
    run([sys.executable, str(root / "scripts" / "prepare_data.py"), "--config", str(root / "configs" / "external.yaml"), "--raw-dir", args.external_raw, "--output-dir", str(external)])
    cross_validation = [sys.executable, str(root / "scripts" / "run_cross_validation.py"), "--config", str(root / "configs" / "outcome_aligned.yaml"), "--data-dir", str(development), "--output-dir", str(work / "outcome_aligned")]
    if args.seed is not None:
        cross_validation.extend(("--seed", str(args.seed)))
    run(cross_validation)
    run([sys.executable, str(root / "scripts" / "run_external.py"), "--config", str(root / "configs" / "external.yaml"), "--development-config", str(root / "configs" / "outcome_aligned.yaml"), "--development-run", str(work / "outcome_aligned"), "--development-data-dir", str(development), "--external-data-dir", str(external), "--output-dir", str(work / "external_evaluation")])


if __name__ == "__main__":
    main()

