#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pficen.config import config_digest, load_config
from pficen.io import discover_data_files, read_event_files
from pficen.protocols import clean_events, construct_fifth_event, positive_prefix_lengths, construct_outcome_aligned, records_to_frames
from pficen.utils import sha256_file, write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare deterministic PFICEN analytical data")
    parser.add_argument("--config", required=True)
    parser.add_argument("--raw-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    config = load_config(args.config)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    files = discover_data_files(args.raw_dir)
    raw = read_event_files(files)
    clean, counts = clean_events(raw)
    clean.to_parquet(output / "clean_events.parquet", index=False)

    session_index = (
        clean.assign(_purchase=clean["event_type"].eq("purchase").astype("int8"))
        .groupby("user_session", sort=False)
        .agg(user_id=("user_id", "first"), label=("_purchase", "max"), first_time=("event_time", "min"), last_time=("event_time", "max"))
        .reset_index()
        .rename(columns={"user_session": "session_id"})
    )
    data_config = config["data"]
    if data_config["protocol"] == "fifth_event":
        records = construct_fifth_event(clean, data_config["landmark_non_purchase_events"], data_config["outcome_horizon_minutes"])
    else:
        lengths = positive_prefix_lengths(clean)
        records = construct_outcome_aligned(clean, lengths, data_config["max_events"], data_config["lookback_hours"], config["run"]["seed"])
    sessions, events = records_to_frames(records)
    session_index = sessions[["session_id", "user_id", "label", "prediction_time"]].merge(
        session_index[["session_id", "first_time", "last_time"]], on="session_id", how="left"
    )
    session_index.to_parquet(output / "session_index.parquet", index=False)
    sessions.to_parquet(output / "sessions.parquet", index=False)
    events.to_parquet(output / "prefix_events.parquet", index=False)
    counts.update({"analytical_sessions": int(len(sessions)), "analytical_events": int(len(events)), "analytical_positives": int(sessions["label"].sum())})
    write_json(counts, output / "construction_counts.json")
    write_json({"sessions": {column: str(dtype) for column, dtype in sessions.dtypes.items()}, "events": {column: str(dtype) for column, dtype in events.dtypes.items()}}, output / "schema.json")
    write_json(
        {
            "config_digest": config_digest(config),
            "input_files": [{"name": path.name, "sha256": sha256_file(path), "bytes": path.stat().st_size} for path in files],
            "protocol": data_config["protocol"],
        },
        output / "preparation_manifest.json",
    )


if __name__ == "__main__":
    main()

