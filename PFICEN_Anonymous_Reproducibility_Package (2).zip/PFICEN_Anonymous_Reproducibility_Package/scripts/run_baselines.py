#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pficen.baselines import aggregate_prefix_features, fit_tabular_baseline
from pficen.calibration import TemperatureScaler, select_f1_threshold
from pficen.config import load_config
from pficen.io import load_prepared
from pficen.metrics import classification_metrics
from pficen.splits import inner_user_split, outer_user_folds
from pficen.utils import write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Run aggregate PFICEN baselines")
    parser.add_argument("--config", required=True)
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    sessions, events = load_prepared(args.data_dir)
    features = aggregate_prefix_features(events, sessions)
    features["outer_fold"] = outer_user_folds(features, 5, config["run"]["seed"])
    supported = ("logistic_regression", "random_forest", "xgboost", "lightgbm", "catboost")
    records = []
    for name in supported:
        for fold in range(5):
            train_all = features.loc[features["outer_fold"] != fold].reset_index(drop=True)
            test = features.loc[features["outer_fold"] == fold].reset_index(drop=True)
            fit_rows, validation_rows = inner_user_split(train_all, 0.10, config["run"]["seed"] + fold)
            fit, validation = train_all.iloc[fit_rows], train_all.iloc[validation_rows]
            model, validation_probability = fit_tabular_baseline(name, config["models"][name], fit, validation)
            validation_logits = pd.Series(validation_probability).clip(1e-7, 1 - 1e-7).map(lambda p: float(__import__("numpy").log(p / (1 - p)))).to_numpy()
            scaler = TemperatureScaler().fit(validation_logits, validation["label"].to_numpy())
            threshold = select_f1_threshold(validation["label"].to_numpy(), scaler.predict_proba(validation_logits))
            from pficen.baselines import AGGREGATE_COLUMNS
            import numpy as np
            x_test = test[list(AGGREGATE_COLUMNS)].replace([np.inf, -np.inf], np.nan).fillna(0.0)
            raw = model.predict_proba(x_test)[:, 1]
            logits = np.log(np.clip(raw, 1e-7, 1 - 1e-7) / np.clip(1 - raw, 1e-7, 1))
            probability = scaler.predict_proba(logits)
            metrics = classification_metrics(test["label"].to_numpy(), probability, threshold)
            run_dir = output / name / f"fold_{fold + 1}"
            run_dir.mkdir(parents=True, exist_ok=True)
            joblib.dump(model, run_dir / "model.joblib")
            pd.DataFrame({"session_id": test["session_id"], "user_id": test["user_id"], "label": test["label"], "probability": probability}).to_parquet(run_dir / "predictions.parquet", index=False)
            write_json({"temperature": scaler.temperature, "threshold": threshold, "metrics": metrics}, run_dir / "metrics.json")
            records.append({"model": name, "fold": fold + 1, **metrics})
    pd.DataFrame(records).to_csv(output / "baseline_summary.csv", index=False)


if __name__ == "__main__":
    main()

