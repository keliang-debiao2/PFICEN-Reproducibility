#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pficen.statistics import holm_adjust, paired_bootstrap


def main() -> None:
    parser = argparse.ArgumentParser(description="Compute paired bootstrap comparisons")
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--comparators-dir")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--replicates", type=int, default=10000)
    args = parser.parse_args()
    run_dir = Path(args.run_dir)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    primary_files = sorted(run_dir.glob("fold_*/seed_*/outer_test_predictions.parquet"))
    if not primary_files:
        raise FileNotFoundError("no PFICEN prediction files were found")
    primary = pd.concat([pd.read_parquet(path) for path in primary_files], ignore_index=True)
    primary = primary.groupby(["session_id", "user_id"], as_index=False).agg(label=("label", "first"), probability=("probability", "mean"))
    records = []
    if args.comparators_dir:
        model_directories = sorted({path.parents[1] for path in Path(args.comparators_dir).glob("*/fold_*/predictions.parquet")})
        for model_directory in model_directories:
            comparator_name = model_directory.name
            comparator = pd.concat([pd.read_parquet(item) for item in model_directory.glob("fold_*/predictions.parquet")], ignore_index=True)
            merged = primary.merge(comparator[["session_id", "probability"]], on="session_id", suffixes=("_pficen", "_comparator"))
            result = paired_bootstrap(merged["label"].to_numpy(), merged["probability_pficen"].to_numpy(), merged["probability_comparator"].to_numpy(), merged["user_id"].to_numpy(), replicates=args.replicates)
            records.append({"comparator": comparator_name, **result})
    if records:
        adjusted = holm_adjust([record["p_value"] for record in records])
        for record, value in zip(records, adjusted, strict=True):
            record["adjusted_p"] = value
    pd.DataFrame(records).to_csv(output / "paired_comparisons.csv", index=False)


if __name__ == "__main__":
    main()

