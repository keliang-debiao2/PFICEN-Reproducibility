#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pficen.config import load_config
from pficen.dataset import EventPrefixDataset, collate_sessions
from pficen.engine import encode_loader, predict
from pficen.metrics import classification_metrics
from pficen.model import PFICEN
from pficen.protocols import construct_fifth_event, construct_outcome_aligned, positive_prefix_lengths, records_to_frames
from pficen.retrieval import LabelStratifiedRetriever
from pficen.splits import inner_user_split
from pficen.utils import write_json


def subset(clean: pd.DataFrame, ids: set[str]) -> pd.DataFrame:
    return clean.loc[clean["user_session"].astype(str).isin(ids)].copy()


def make_retriever(config: dict) -> LabelStratifiedRetriever:
    retrieval = config["retrieval"]
    return LabelStratifiedRetriever(
        dimension=retrieval["dimension"], nlist=retrieval["nlist"], nprobe=retrieval["nprobe"],
        fallback_nprobe=retrieval["fallback_nprobe"], initial_candidates=retrieval["initial_candidates_per_label"],
        fallback_candidates=retrieval["fallback_candidates_per_label"], contexts_per_label=retrieval["positive_contexts"],
        near_duration_ratio=retrieval["near_duplicate_duration_ratio"],
    )


def build_records(config: dict, events: pd.DataFrame, training_lengths=None):
    data = config["data"]
    if data["protocol"] == "fifth_event":
        return construct_fifth_event(events, data["landmark_non_purchase_events"], data["outcome_horizon_minutes"])
    return construct_outcome_aligned(events, training_lengths, data["max_events"], data["lookback_hours"], config["run"]["seed"])


def main() -> None:
    parser = argparse.ArgumentParser(description="Run frozen-fold external PFICEN evaluation")
    parser.add_argument("--config", required=True)
    parser.add_argument("--development-config", default="configs/outcome_aligned.yaml")
    parser.add_argument("--development-run", required=True)
    parser.add_argument("--development-data-dir", required=True)
    parser.add_argument("--external-data-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    external_config = load_config(args.config)
    config = load_config(args.development_config)
    run_dir = Path(args.development_run)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    development_clean = pd.read_parquet(Path(args.development_data_dir) / "clean_events.parquet")
    external_clean = pd.read_parquet(Path(args.external_data_dir) / "clean_events.parquet")
    assignment = pd.read_parquet(run_dir / "outer_fold_assignment.parquet")
    assignment["session_id"] = assignment["session_id"].astype(str)
    device = torch.device(args.device)
    all_predictions = []

    for fold in range(config["data"]["outer_folds"]):
        outer_train = assignment.loc[assignment["outer_fold"] != fold].reset_index(drop=True)
        fit_rows, _ = inner_user_split(outer_train, config["data"]["inner_user_fraction"], config["run"]["seed"] + fold)
        fit_index = outer_train.iloc[fit_rows]
        outer_train_events = subset(development_clean, set(outer_train["session_id"]))
        lengths = positive_prefix_lengths(outer_train_events) if config["data"]["protocol"] == "outcome_aligned" else None
        fit_records = build_records(config, subset(development_clean, set(fit_index["session_id"])), lengths)
        fit_sessions, fit_events = records_to_frames(fit_records)
        external_records = build_records(external_config, external_clean, lengths)
        external_sessions, external_events = records_to_frames(external_records)
        preprocessor = joblib.load(run_dir / f"fold_{fold + 1}" / "preprocessor.joblib")
        fit_events = preprocessor.transform(fit_events)
        sequence_length = config["data"].get("max_events", config["data"].get("landmark_non_purchase_events", 5))
        external_length = external_config["data"].get("max_events", external_config["data"].get("landmark_non_purchase_events", 5))
        fit_loader = DataLoader(EventPrefixDataset(fit_sessions, fit_events, sequence_length), batch_size=config["optimization"]["batch_size"], shuffle=False, num_workers=args.workers, collate_fn=collate_sessions)
        for seed_dir in sorted((run_dir / f"fold_{fold + 1}").glob("seed_*")):
            checkpoint = torch.load(seed_dir / "best_checkpoint.pt", map_location=device, weights_only=False)
            model_keys = ("hidden_dim", "encoder_layers", "context_layers", "attention_heads", "feedforward_dim", "dropout", "experts", "active_experts", "expert_hidden_dim", "use_time_bias", "use_funnel_bias", "use_experts")
            model = PFICEN(preprocessor.vocabulary_sizes(), **{key: config["model"][key] for key in model_keys if key in config["model"]}, max_events=sequence_length, time_bins=config["data"]["time_bins"])
            model.load_state_dict(checkpoint["model"])
            model.to(device)
            retriever = make_retriever(config)
            vectors, labels, metadata = encode_loader(model, fit_loader, device)
            retriever.build(vectors, labels, metadata)
            for removal in external_config["feature_removal"]:
                condition_events = external_events.copy()
                for field in removal["remove"]:
                    condition_events[field] = np.nan
                condition_events = preprocessor.transform(condition_events)
                external_loader = DataLoader(EventPrefixDataset(external_sessions, condition_events, external_length), batch_size=config["optimization"]["batch_size"], shuffle=False, num_workers=args.workers, collate_fn=collate_sessions)
                bundle = predict(model, external_loader, device, retriever)
                temperature = float(checkpoint["temperature"])
                probability = 1.0 / (1.0 + np.exp(-bundle.logits / temperature))
                all_predictions.append(pd.DataFrame({"session_id": bundle.session_id, "label": bundle.labels.astype(int), "probability": probability, "fold": fold + 1, "seed": int(seed_dir.name.split("_")[-1]), "configuration": removal["name"]}))

    stacked = pd.concat(all_predictions, ignore_index=True)
    ensemble = stacked.groupby(["configuration", "session_id"], sort=False).agg(label=("label", "first"), probability=("probability", "mean")).reset_index()
    threshold = float(external_config["inference"]["external_f1_threshold"])
    metrics = {name: classification_metrics(group["label"].to_numpy(), group["probability"].to_numpy(), threshold) for name, group in ensemble.groupby("configuration", sort=False)}
    stacked.to_parquet(output / "fold_seed_predictions.parquet", index=False)
    ensemble.to_parquet(output / "ensemble_predictions.parquet", index=False)
    write_json({"threshold": threshold, "metrics": metrics, "fold_models": config["data"]["outer_folds"], "adaptation": False}, output / "external_metrics.json")


if __name__ == "__main__":
    main()

