#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pficen.config import load_config
from pficen.model import PFICEN


def main() -> None:
    parser = argparse.ArgumentParser(description="Profile PFICEN neural inference")
    parser.add_argument("--config", required=True)
    parser.add_argument("--vocabulary-sizes", required=True, help="JSON with product, category, and brand sizes")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--iterations", type=int, default=500)
    args = parser.parse_args()
    config = load_config(args.config)
    with Path(args.vocabulary_sizes).open("r", encoding="utf-8") as handle:
        vocabulary_sizes = json.load(handle)
    model_keys = ("hidden_dim", "encoder_layers", "context_layers", "attention_heads", "feedforward_dim", "dropout", "experts", "active_experts", "expert_hidden_dim", "use_time_bias", "use_funnel_bias", "use_experts")
    model = PFICEN(vocabulary_sizes, **{key: config["model"][key] for key in model_keys if key in config["model"]}, max_events=config["data"]["max_events"], time_bins=config["data"]["time_bins"]).to(args.device).eval()
    length = config["data"]["max_events"]
    batch = {
        "event_id": torch.zeros(1, length, dtype=torch.long, device=args.device),
        "product": torch.zeros(1, length, dtype=torch.long, device=args.device),
        "category": torch.zeros(1, length, dtype=torch.long, device=args.device),
        "brand": torch.zeros(1, length, dtype=torch.long, device=args.device),
        "price": torch.zeros(1, length, device=args.device),
        "price_missing": torch.zeros(1, length, device=args.device),
        "time_seconds": torch.arange(length, dtype=torch.float32, device=args.device)[None, :],
        "mask": torch.ones(1, length, dtype=torch.bool, device=args.device),
    }
    context_vectors = torch.zeros(1, 64, config["model"]["hidden_dim"], device=args.device)
    context_labels = torch.cat((torch.ones(1, 32), torch.zeros(1, 32)), dim=1).long().to(args.device)
    with torch.no_grad():
        for _ in range(50):
            model(batch, context_vectors, context_labels)
        if args.device.startswith("cuda"):
            torch.cuda.synchronize()
        timings = []
        for _ in range(args.iterations):
            start = time.perf_counter()
            model(batch, context_vectors, context_labels)
            if args.device.startswith("cuda"):
                torch.cuda.synchronize()
            timings.append((time.perf_counter() - start) * 1000)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    with (output / "neural_profile.json").open("w", encoding="utf-8") as handle:
        json.dump({"parameters": sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad), "iterations": args.iterations, "latency_ms_mean": statistics.mean(timings), "latency_ms_median": statistics.median(timings), "device": args.device}, handle, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()

