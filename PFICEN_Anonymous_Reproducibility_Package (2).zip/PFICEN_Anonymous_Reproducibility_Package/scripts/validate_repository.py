#!/usr/bin/env python
from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path

import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def main() -> None:
    required = [
        "README.md", "LICENSE", "CITATION.cff", "pyproject.toml", "requirements.txt", "environment.yml",
        "configs/outcome_aligned.yaml", "configs/fifth_event.yaml", "configs/external.yaml", "configs/baselines.yaml",
        "docs/PROTOCOL.md", "docs/DATA_SCHEMA.md", "docs/METHOD_MAPPING.md", "docs/RESULT_PROVENANCE.md",
        "results/reference/internal_baselines.csv", "results/reference/external_baselines.csv", "results/reference/ablations.csv",
        "logs/reference_runs/manifest.json",
    ]
    missing = [path for path in required if not (ROOT / path).is_file()]
    if missing:
        raise SystemExit(f"missing required files: {missing}")
    for path in (ROOT / "configs").glob("*.yaml"):
        with path.open("r", encoding="utf-8") as handle:
            if not isinstance(yaml.safe_load(handle), dict):
                raise SystemExit(f"invalid configuration: {path}")
    for path in (ROOT / "results" / "reference").glob("*.csv"):
        frame = pd.read_csv(path)
        if frame.empty:
            raise SystemExit(f"empty result table: {path}")
    with (ROOT / "logs" / "reference_runs" / "manifest.json").open("r", encoding="utf-8") as handle:
        manifest = json.load(handle)
    if manifest.get("trace_status") != "manuscript_aligned_reference":
        raise SystemExit("reference trace status is invalid")
    for module in ("pficen.protocols", "pficen.splits", "pficen.preprocessing", "pficen.model", "pficen.losses", "pficen.metrics", "pficen.statistics"):
        importlib.import_module(module)
    print("repository validation passed")


if __name__ == "__main__":
    main()

