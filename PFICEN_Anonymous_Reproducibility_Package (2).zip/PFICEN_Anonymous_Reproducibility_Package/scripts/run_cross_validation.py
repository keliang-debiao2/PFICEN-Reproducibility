#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pficen.calibration import TemperatureScaler
from pficen.config import load_config, save_resolved_config
from pficen.dataset import EventPrefixDataset, collate_sessions
from pficen.engine import predict, train_model
from pficen.metrics import classification_metrics
from pficen.model import PFICEN
from pficen.preprocessing import FoldPreprocessor
from pficen.protocols import construct_fifth_event, construct_outcome_aligned, positive_prefix_lengths, records_to_frames
from pficen.splits import inner_user_split, outer_user_folds
from pficen.utils import set_global_seed, write_json


def records_for(config, events, training_lengths=None):
    data = config["data"]
    if data["protocol"] == "fifth_event":
        return construct_fifth_event(events, data["landmark_non_purchase_events"], data["outcome_horizon_minutes"])
    return construct_outcome_aligned(events, training_lengths, data["max_events"], data["lookback_hours"], config["run"]["seed"])


def subset_events(clean: pd.DataFrame, session_ids: set[str]) -> pd.DataFrame:
    return clean.loc[clean["user_session"].astype(str).isin(session_ids)].copy()


def main() -> None:
    parser = argparse.ArgumentParser(description="Run user-grouped PFICEN cross-validation")
    parser.add_argument("--config", required=True)
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    config = load_config(args.config)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    save_resolved_config(config, output / "resolved_config.yaml")
    clean = pd.read_parquet(Path(args.data_dir) / "clean_events.parquet")
    session_index = pd.read_parquet(Path(args.data_dir) / "session_index.parquet")
    session_index["session_id"] = session_index["session_id"].astype(str)
    fold_assignment = outer_user_folds(session_index, config["data"]["outer_folds"], config["run"]["seed"])
    session_index["outer_fold"] = fold_assignment
    session_index.to_parquet(output / "outer_fold_assignment.parquet", index=False)
    fitting_seeds = [args.seed] if args.seed is not None else config["run"]["fitting_seeds"]
    summaries = []

    for fold in range(config["data"]["outer_folds"]):
        outer_train_index = session_index.loc[session_index["outer_fold"] != fold].reset_index(drop=True)
        outer_test_index = session_index.loc[session_index["outer_fold"] == fold].reset_index(drop=True)
        fit_rows, validation_rows = inner_user_split(outer_train_index, config["data"]["inner_user_fraction"], config["run"]["seed"] + fold)
        fit_index = outer_train_index.iloc[fit_rows]
        validation_index = outer_train_index.iloc[validation_rows]
        training_user_fraction = float(config["data"].get("training_user_fraction", 1.0))
        if training_user_fraction < 1.0:
            users = fit_index["user_id"].astype(str).unique()
            rng = np.random.default_rng(config["run"]["seed"] + fold)
            selected = rng.choice(users, size=max(1, int(round(len(users) * training_user_fraction))), replace=False)
            fit_index = fit_index.loc[fit_index["user_id"].astype(str).isin(selected)]
        outer_train_events = subset_events(clean, set(outer_train_index["session_id"]))
        lengths = positive_prefix_lengths(outer_train_events) if config["data"]["protocol"] == "outcome_aligned" else None
        partitions = {}
        for name, index in (("fit", fit_index), ("validation", validation_index), ("test", outer_test_index)):
            frame = subset_events(clean, set(index["session_id"]))
            partitions[name] = records_to_frames(records_for(config, frame, lengths))
        fit_sessions, fit_events = partitions["fit"]
        preprocessor = FoldPreprocessor(tuple(config["data"]["price_clip_quantiles"])).fit(fit_events)
        transformed = {name: (sessions, preprocessor.transform(events)) for name, (sessions, events) in partitions.items()}
        (output / f"fold_{fold + 1}").mkdir(parents=True, exist_ok=True)
        joblib.dump(preprocessor, output / f"fold_{fold + 1}" / "preprocessor.joblib")

        datasets = {name: EventPrefixDataset(sessions, events, config["data"].get("max_events", 5)) for name, (sessions, events) in transformed.items()}
        loaders = {
            name: DataLoader(dataset, batch_size=config["optimization"]["batch_size"], shuffle=name == "fit", num_workers=args.workers, collate_fn=collate_sessions, pin_memory=args.device.startswith("cuda"))
            for name, dataset in datasets.items()
        }
        for seed in fitting_seeds:
            run_dir = output / f"fold_{fold + 1}" / f"seed_{seed}"
            set_global_seed(seed, config["run"].get("deterministic", True))
            model_keys = ("hidden_dim", "encoder_layers", "context_layers", "attention_heads", "feedforward_dim", "dropout", "experts", "active_experts", "expert_hidden_dim", "use_time_bias", "use_funnel_bias", "use_experts")
            model = PFICEN(preprocessor.vocabulary_sizes(), **{key: config["model"][key] for key in model_keys if key in config["model"]}, max_events=config["data"].get("max_events", 5), time_bins=config["data"]["time_bins"])
            model, retriever, checkpoint = train_model(model, loaders["fit"], loaders["validation"], config, run_dir, args.device)
            bundle = predict(model, loaders["test"], torch.device(args.device), retriever)
            scaler = TemperatureScaler()
            scaler.temperature = float(checkpoint["temperature"])
            probabilities = scaler.predict_proba(bundle.logits)
            metrics = classification_metrics(bundle.labels, probabilities, float(checkpoint["threshold"]), config["calibration"]["ece_bins"])
            predictions = pd.DataFrame({"session_id": bundle.session_id, "user_id": bundle.user_id, "label": bundle.labels.astype(int), "logit": bundle.logits, "probability": probabilities, "fold": fold + 1, "seed": seed})
            predictions.to_parquet(run_dir / "outer_test_predictions.parquet", index=False)
            write_json({"fold": fold + 1, "seed": seed, "temperature": checkpoint["temperature"], "threshold": checkpoint["threshold"], "metrics": metrics}, run_dir / "outer_test_metrics.json")
            summaries.append({"fold": fold + 1, "seed": seed, **metrics})
    pd.DataFrame(summaries).to_csv(output / "cross_validation_summary.csv", index=False)
    with (output / "completion.json").open("w", encoding="utf-8") as handle:
        json.dump({"status": "complete", "folds": config["data"]["outer_folds"], "seeds": fitting_seeds}, handle, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()

