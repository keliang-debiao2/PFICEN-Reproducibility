#!/usr/bin/env python
from __future__ import annotations

import argparse
import copy
import subprocess
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
import yaml
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pficen.config import load_config
from pficen.dataset import EventPrefixDataset, collate_sessions
from pficen.engine import encode_loader, predict
from pficen.metrics import classification_metrics
from pficen.model import PFICEN
from pficen.perturbations import feature_missingness, fixed_prefix, price_noise
from pficen.protocols import construct_outcome_aligned, positive_prefix_lengths, records_to_frames
from pficen.retrieval import LabelStratifiedRetriever
from pficen.splits import inner_user_split


def subset(clean: pd.DataFrame, ids: set[str]) -> pd.DataFrame:
    return clean.loc[clean["user_session"].astype(str).isin(ids)].copy()


def retriever_from_config(config: dict) -> LabelStratifiedRetriever:
    item = config["retrieval"]
    return LabelStratifiedRetriever(item["dimension"], item["nlist"], item["nprobe"], item["fallback_nprobe"], item["initial_candidates_per_label"], item["fallback_candidates_per_label"], item["positive_contexts"], item["near_duplicate_duration_ratio"])


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate PFICEN controlled robustness conditions")
    parser.add_argument("--config", required=True)
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--base-run", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    specification = load_config(args.config)
    base = load_config(specification["base_config"])
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    clean = pd.read_parquet(Path(args.data_dir) / "clean_events.parquet")
    assignment = pd.read_parquet(Path(args.base_run) / "outer_fold_assignment.parquet")
    assignment["session_id"] = assignment["session_id"].astype(str)
    device = torch.device(args.device)
    records = []

    for condition in specification["conditions"]:
        if condition["mode"] == "retrain":
            for seed in specification["seeds"]:
                config = copy.deepcopy(base)
                config["data"]["training_user_fraction"] = float(condition["user_fraction"])
                config_path = output / f"{condition['name']}_seed_{seed}.yaml"
                with config_path.open("w", encoding="utf-8") as handle:
                    yaml.safe_dump(config, handle, sort_keys=False)
                subprocess.run([sys.executable, str(ROOT / "scripts" / "run_cross_validation.py"), "--config", str(config_path), "--data-dir", args.data_dir, "--output-dir", str(output / condition["name"] / f"seed_{seed}"), "--seed", str(seed)], check=True)
            continue
        for seed in specification["seeds"]:
            for fold in range(base["data"]["outer_folds"]):
                outer_train = assignment.loc[assignment["outer_fold"] != fold].reset_index(drop=True)
                outer_test = assignment.loc[assignment["outer_fold"] == fold].reset_index(drop=True)
                fit_rows, _ = inner_user_split(outer_train, base["data"]["inner_user_fraction"], base["run"]["seed"] + fold)
                fit_index = outer_train.iloc[fit_rows]
                outer_train_events = subset(clean, set(outer_train["session_id"]))
                lengths = positive_prefix_lengths(outer_train_events)
                fit_sessions, fit_events = records_to_frames(construct_outcome_aligned(subset(clean, set(fit_index["session_id"])), lengths, base["data"]["max_events"], base["data"]["lookback_hours"], base["run"]["seed"]))
                test_sessions, test_events = records_to_frames(construct_outcome_aligned(subset(clean, set(outer_test["session_id"])), lengths, base["data"]["max_events"], base["data"]["lookback_hours"], base["run"]["seed"]))
                if condition["name"] == "feature_missingness_20pct":
                    test_events = feature_missingness(test_events, condition["probability"], seed)
                elif condition["name"] == "price_noise_10pct":
                    test_events = price_noise(test_events, condition["log_normal_sigma"], seed)
                elif condition["name"] == "fixed_three_event_prefix":
                    test_events = fixed_prefix(test_events, condition["retained_events"])
                    test_sessions = test_sessions.loc[test_sessions["session_id"].isin(test_events["session_id"].unique())].copy()
                preprocessor = joblib.load(Path(args.base_run) / f"fold_{fold + 1}" / "preprocessor.joblib")
                fit_events = preprocessor.transform(fit_events)
                test_events = preprocessor.transform(test_events)
                fit_loader = DataLoader(EventPrefixDataset(fit_sessions, fit_events, base["data"]["max_events"]), batch_size=base["optimization"]["batch_size"], shuffle=False, num_workers=args.workers, collate_fn=collate_sessions)
                test_loader = DataLoader(EventPrefixDataset(test_sessions, test_events, base["data"]["max_events"]), batch_size=base["optimization"]["batch_size"], shuffle=False, num_workers=args.workers, collate_fn=collate_sessions)
                checkpoint_path = Path(args.base_run) / f"fold_{fold + 1}" / f"seed_{seed}" / "best_checkpoint.pt"
                if not checkpoint_path.exists():
                    available = sorted((Path(args.base_run) / f"fold_{fold + 1}").glob("seed_*/best_checkpoint.pt"))
                    if not available:
                        raise FileNotFoundError(f"no checkpoint for fold {fold + 1}")
                    checkpoint_path = available[0]
                checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
                model_keys = ("hidden_dim", "encoder_layers", "context_layers", "attention_heads", "feedforward_dim", "dropout", "experts", "active_experts", "expert_hidden_dim", "use_time_bias", "use_funnel_bias", "use_experts")
                model = PFICEN(preprocessor.vocabulary_sizes(), **{key: base["model"][key] for key in model_keys if key in base["model"]}, max_events=base["data"]["max_events"], time_bins=base["data"]["time_bins"])
                model.load_state_dict(checkpoint["model"])
                model.to(device)
                retriever = retriever_from_config(base)
                vectors, labels, metadata = encode_loader(model, fit_loader, device)
                retriever.build(vectors, labels, metadata)
                bundle = predict(model, test_loader, device, retriever)
                probability = 1.0 / (1.0 + np.exp(-bundle.logits / float(checkpoint["temperature"])))
                metrics = classification_metrics(bundle.labels, probability, float(checkpoint["threshold"]), base["calibration"]["ece_bins"])
                records.append({"condition": condition["name"], "seed": seed, "fold": fold + 1, **metrics})
    pd.DataFrame(records).to_csv(output / "evaluation_conditions.csv", index=False)


if __name__ == "__main__":
    main()

