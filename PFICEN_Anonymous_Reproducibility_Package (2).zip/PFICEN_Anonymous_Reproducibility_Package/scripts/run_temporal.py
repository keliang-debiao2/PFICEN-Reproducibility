#!/usr/bin/env python
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pficen.calibration import TemperatureScaler
from pficen.config import load_config
from pficen.dataset import EventPrefixDataset, collate_sessions
from pficen.engine import predict, train_model
from pficen.metrics import classification_metrics
from pficen.model import PFICEN
from pficen.preprocessing import FoldPreprocessor
from pficen.splits import chronological_fifth_event_split
from pficen.utils import set_global_seed, write_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Run chronological fifth-event confirmation")
    parser.add_argument("--config", required=True)
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    config = load_config(args.config)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    sessions = pd.read_parquet(Path(args.data_dir) / "sessions.parquet")
    events = pd.read_parquet(Path(args.data_dir) / "prefix_events.parquet")
    sessions["temporal_split"] = chronological_fifth_event_split(sessions)
    sessions.to_parquet(output / "temporal_assignment.parquet", index=False)
    train_sessions = sessions.loc[sessions["temporal_split"] == "train"]
    train_events = events.loc[events["session_id"].isin(train_sessions["session_id"])]
    preprocessor = FoldPreprocessor(tuple(config["data"]["price_clip_quantiles"])).fit(train_events)
    metrics = []
    for seed in config["run"]["fitting_seeds"]:
        loaders = {}
        for name in ("train", "validation", "test"):
            part_sessions = sessions.loc[sessions["temporal_split"] == name]
            part_events = events.loc[events["session_id"].isin(part_sessions["session_id"])]
            part_events = preprocessor.transform(part_events)
            loaders[name] = DataLoader(EventPrefixDataset(part_sessions, part_events, 5), batch_size=config["optimization"]["batch_size"], shuffle=name == "train", num_workers=args.workers, collate_fn=collate_sessions)
        set_global_seed(seed)
        model_keys = ("hidden_dim", "encoder_layers", "context_layers", "attention_heads", "feedforward_dim", "dropout", "experts", "active_experts", "expert_hidden_dim", "use_time_bias", "use_funnel_bias", "use_experts")
        model = PFICEN(preprocessor.vocabulary_sizes(), **{key: config["model"][key] for key in model_keys if key in config["model"]}, max_events=5, time_bins=config["data"]["time_bins"])
        model, retriever, checkpoint = train_model(model, loaders["train"], loaders["validation"], config, output / f"seed_{seed}", args.device)
        bundle = predict(model, loaders["test"], torch.device(args.device), retriever)
        scaler = TemperatureScaler()
        scaler.temperature = float(checkpoint["temperature"])
        probability = scaler.predict_proba(bundle.logits)
        result = classification_metrics(bundle.labels, probability, float(checkpoint["threshold"]), config["calibration"]["ece_bins"])
        pd.DataFrame({"session_id": bundle.session_id, "user_id": bundle.user_id, "label": bundle.labels.astype(int), "probability": probability}).to_parquet(output / f"seed_{seed}" / "temporal_test_predictions.parquet", index=False)
        write_json(result, output / f"seed_{seed}" / "temporal_test_metrics.json")
        metrics.append({"seed": seed, **result})
    pd.DataFrame(metrics).to_csv(output / "temporal_summary.csv", index=False)


if __name__ == "__main__":
    main()

