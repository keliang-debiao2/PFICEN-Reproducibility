#!/usr/bin/env python
from __future__ import annotations

import argparse
import copy
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pficen.config import load_config


def variant_config(base: dict, name: str) -> dict:
    config = copy.deepcopy(base)
    config["run"]["name"] = f"ablation_{name}"
    config["model"]["use_time_bias"] = True
    config["model"]["use_funnel_bias"] = True
    config["model"]["use_experts"] = True
    config["retrieval"]["enabled"] = True
    if name == "without_time_bias":
        config["model"]["use_time_bias"] = False
        config["model"]["use_funnel_bias"] = False
    elif name == "without_retrieval":
        config["retrieval"]["enabled"] = False
        config["optimization"]["lambda_retrieval"] = 0.0
    elif name == "without_sparse_experts":
        config["model"]["use_experts"] = False
    elif name == "without_funnel_loss":
        config["optimization"]["lambda_funnel"] = 0.0
    elif name == "without_calibration_loss":
        config["optimization"]["lambda_calibration"] = 0.0
    elif name == "retrieval_and_experts":
        config["optimization"]["lambda_funnel"] = 0.0
    elif name == "funnel_and_experts":
        config["retrieval"]["enabled"] = False
        config["optimization"]["lambda_retrieval"] = 0.0
    elif name == "funnel_and_retrieval":
        config["model"]["use_experts"] = False
    elif name == "funnel_only":
        config["retrieval"]["enabled"] = False
        config["optimization"]["lambda_retrieval"] = 0.0
        config["model"]["use_experts"] = False
    elif name == "capacity_matched_transformer":
        config["retrieval"]["enabled"] = False
        config["optimization"]["lambda_retrieval"] = 0.0
        config["optimization"]["lambda_funnel"] = 0.0
        config["model"]["use_experts"] = False
        config["model"]["encoder_layers"] = 6
        config["model"]["feedforward_dim"] = 1024
    return config


def main() -> None:
    parser = argparse.ArgumentParser(description="Run PFICEN component and interaction ablations")
    parser.add_argument("--config", required=True)
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--seed", type=int)
    args = parser.parse_args()
    specification = load_config(args.config)
    base = load_config(specification["base_config"])
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    for name in specification["variants"]:
        config = variant_config(base, name)
        config_path = output / f"config_{name}.yaml"
        with config_path.open("w", encoding="utf-8") as handle:
            yaml.safe_dump(config, handle, sort_keys=False)
        command = [sys.executable, str(ROOT / "scripts" / "run_cross_validation.py"), "--config", str(config_path), "--data-dir", args.data_dir, "--output-dir", str(output / name)]
        if args.seed is not None:
            command.extend(("--seed", str(args.seed)))
        subprocess.run(command, check=True)
    for value in specification["lambda_funnel_sensitivity"]:
        config = copy.deepcopy(base)
        config["optimization"]["lambda_funnel"] = float(value)
        label = str(value).replace(".", "p")
        config_path = output / f"config_lambda_funnel_{label}.yaml"
        with config_path.open("w", encoding="utf-8") as handle:
            yaml.safe_dump(config, handle, sort_keys=False)
        command = [sys.executable, str(ROOT / "scripts" / "run_cross_validation.py"), "--config", str(config_path), "--data-dir", args.data_dir, "--output-dir", str(output / f"lambda_funnel_{label}")]
        if args.seed is not None:
            command.extend(("--seed", str(args.seed)))
        subprocess.run(command, check=True)


if __name__ == "__main__":
    main()

