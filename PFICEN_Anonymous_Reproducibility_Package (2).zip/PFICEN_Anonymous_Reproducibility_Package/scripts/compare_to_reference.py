#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare a completed run with manuscript-aligned targets")
    parser.add_argument("--run-summary", required=True)
    parser.add_argument("--reference", default="results/reference/internal_baselines.csv")
    parser.add_argument("--model", default="PFICEN")
    parser.add_argument("--absolute-tolerance", type=float, default=0.01)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    run = pd.read_csv(args.run_summary)
    reference = pd.read_csv(args.reference)
    target = reference.loc[reference["model"] == args.model].iloc[0]
    observed = run.groupby("fold", as_index=False)[["pr_auc", "roc_auc", "f1", "brier", "ece"]].mean()
    summary = {metric: float(observed[metric].mean()) for metric in ("pr_auc", "roc_auc", "f1", "brier", "ece")}
    differences = {metric: summary[metric] - float(target["mean_pr_auc"] if metric == "pr_auc" else target[metric]) for metric in summary}
    passed = all(abs(value) <= args.absolute_tolerance for value in differences.values())
    payload = {"model": args.model, "absolute_tolerance": args.absolute_tolerance, "observed": summary, "differences": differences, "within_tolerance": bool(passed)}
    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
    if not passed:
        raise SystemExit("one or more metrics exceed the requested tolerance")


if __name__ == "__main__":
    main()

