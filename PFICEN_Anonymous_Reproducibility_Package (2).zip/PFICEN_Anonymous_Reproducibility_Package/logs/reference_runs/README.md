# Reference Run Records

These files encode manuscript-aligned target traces and the expected logging structure. They are reconstructed from confirmed paper values and fixed configurations, not captured from the original training host. Newly executed runs must be written outside this directory.

The `manifest.json` file records this status in machine-readable form. See `docs/RESULT_PROVENANCE.md` before using the records in any reproducibility statement.

